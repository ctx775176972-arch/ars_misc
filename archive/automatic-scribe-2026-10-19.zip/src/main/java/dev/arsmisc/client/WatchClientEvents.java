package dev.arsmisc.client;

import dev.arsmisc.ArsMiscMod;
import dev.arsmisc.registry.ModMenus;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterMenuScreensEvent;

@EventBusSubscriber(modid=ArsMiscMod.MOD_ID, bus=EventBusSubscriber.Bus.MOD, value=Dist.CLIENT)
public final class WatchClientEvents {
    @SubscribeEvent public static void registerScreens(RegisterMenuScreensEvent event) {
        event.register(ModMenus.ENCHANTERS_POCKET_WATCH.get(), EnchantersPocketWatchScreen::new);
        event.register(ModMenus.ENCHANTERS_FIELD.get(), EnchantersFieldScreen::new);
        event.register(ModMenus.REALITY_MARBLE.get(), RealityMarbleScreen::new);
    }
    @SubscribeEvent public static void registerKeys(net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent event) { event.register(CastingKeys.TOGGLE); event.register(CastingKeys.MINING_RANGE); }
}
