package dev.arsmisc.client;

import java.lang.reflect.Method;
import java.util.Locale;

/** Shares the pack's Just Enough Characters matcher without requiring that mod. */
public final class GlyphSearch {
    private static Method pinyinMatcher = findMatcher();
    private GlyphSearch() { }
    private static Method findMatcher() {
        try {
            return Class.forName("me.towdium.jecharacters.utils.Match").getMethod("contains", String.class, CharSequence.class);
        } catch (ReflectiveOperationException | LinkageError exception) {
            return null;
        }
    }
    public static boolean matches(String label, String id, String query) {
        String term = query.strip().toLowerCase(Locale.ROOT);
        if (term.isEmpty() || label.toLowerCase(Locale.ROOT).contains(term) || id.toLowerCase(Locale.ROOT).contains(term)) return true;
        if (pinyinMatcher == null) return false;
        try {
            return (boolean) pinyinMatcher.invoke(null, label.toLowerCase(Locale.ROOT), term);
        } catch (ReflectiveOperationException | LinkageError exception) {
            pinyinMatcher = null;
            return false;
        }
    }
}
