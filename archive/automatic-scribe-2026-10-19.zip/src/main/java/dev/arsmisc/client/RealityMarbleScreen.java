package dev.arsmisc.client;

import com.hollingsworth.arsnouveau.api.registry.*;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.client.gui.utils.RenderUtils;
import com.hollingsworth.arsnouveau.setup.registry.CapabilityRegistry;
import dev.arsmisc.item.RealityMarbleItem;
import dev.arsmisc.menu.RealityMarbleMenu;
import dev.arsmisc.network.RealityMarbleEditPayload;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.*;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.neoforged.neoforge.network.PacketDistributor;
import java.util.*;

/** Independent glyph-workbench layout: palette above two selectable spell rows. */
public final class RealityMarbleScreen extends AbstractContainerScreen<RealityMarbleMenu> {
    private static final net.minecraft.resources.ResourceLocation BOOK = net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("ars_nouveau", "textures/gui/spell_book_template.png");
    private static final net.minecraft.resources.ResourceLocation GLYPH_SLOT = net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("ars_nouveau", "textures/gui/spell_glyph_slot.png");
    private static final int GLYPHS_PER_PAGE = 40;
    private static final int SPELL_ROW_TOP = 131, SPELL_ROW_SPACING = 36;
    private static final int INK = 0xFF3B2946, MUTED = 0xFF75677A;
    private final List<List<AbstractSpellPart>> drafts = List.of(new ArrayList<>(), new ArrayList<>());
    private final boolean[] dirty = new boolean[2];
    private final List<Button> dynamic = new ArrayList<>();
    private final List<Button> paletteControls = new ArrayList<>();
    private EditBox search, interval, radius;
    private Button toggle, save, clear, radiusApply;
    private int channel, page, soundChannel = -1, soundPage;
    private boolean initialized;
    private String paletteSignature = "";

    public RealityMarbleScreen(RealityMarbleMenu menu, Inventory inv, Component title) {
        super(menu, inv, title); imageWidth = 392; imageHeight = 232;
        titleLabelY = inventoryLabelY = -1000;
    }
    public static Component text(String key, Object... args) { return Component.translatable("gui.ars_misc.marble." + key, args); }
    private AbstractCaster<?> caster() { return ((RealityMarbleItem) menu.stack().getItem()).getSpellCaster(menu.stack()); }
    private void send(int action) {
        if (minecraft != null && minecraft.gameMode != null) minecraft.gameMode.handleInventoryButtonClick(menu.containerId, action);
    }
    private Button button(Component label, int x, int y, int w, int h, Runnable action) {
        return addRenderableWidget(Button.builder(label, b -> action.run()).bounds(leftPos+x, topPos+y,w,h).build());
    }
    private Button arrow(boolean next, int x, int y, Runnable action) {
        return addRenderableWidget(new PageArrow(leftPos+x,topPos+y,next,action));
    }
    private EditBox field(int x, int y, int w, Component label) {
        var box = new EditBox(font,leftPos+x,topPos+y,w,16,label); addRenderableWidget(box); return box;
    }
    @Override protected void init() {
        super.init(); dynamic.clear();paletteControls.clear();paletteSignature = "";
        search = field(14,13,184,text("search")); search.setMaxLength(64); search.setHint(text("search"));
        paletteControls.add(arrow(false,202,12,()->{page=Math.max(0,page-1); rebuildPalette();}));
        paletteControls.add(arrow(true,229,12,()->{page=Math.min(maxPage(),page+1); rebuildPalette();}));
        interval = field(280,70,51,text("seconds")); interval.setMaxLength(4); interval.setFilter(s->s.matches("[0-9]*"));
        button(text("apply"),334,69,44,18,()->{
            try {int v=Integer.parseInt(interval.getValue());if(v>=1&&v<=3600)send((channel==0?1000:5000)+v);}catch(NumberFormatException ignored){}
        });
        radius=field(280,132,51,text("radius")); radius.setMaxLength(4);radius.setFilter(s->s.matches("[0-9]*([.][0-9]?)?"));
        radiusApply=button(text("apply"),334,131,44,18,()->{
            try {int v=(int)Math.round(Double.parseDouble(radius.getValue())*10);if(v>=10&&v<=160)send(10000+v);}catch(NumberFormatException ignored){}
        });
        radius.setTooltip(Tooltip.create(text("radius_limits")));
        button(text("start_sound"),280,154,98,18,()->openSounds(2));
        toggle=button(text("paused"),280,194,98,18,()->send(1));
        toggle.setTooltip(Tooltip.create(text("upkeep",menu.radiusSetting()/10.0)));
        save=button(text("save"),14,198,100,14,this::save);
        clear=button(text("clear"),120,198,90,14,()->{drafts.get(channel).clear();dirty[channel]=true;});
        button(Component.translatable("gui.done"),215,198,45,14,this::onClose);
        refreshDrafts();select(channel);rebuildPalette();
    }
    private void refreshDrafts() {
        var caster=caster();
        for(int c=0;c<2;c++) if(dirty[c] && drafts.get(c).equals(dev.arsmisc.item.EnchantersFieldItem.directSpell(caster.getSpell(c)).unsafeList())) dirty[c]=false;
        for(int c=0;c<2;c++) if(!dirty[c]) {
            drafts.get(c).clear();
            drafts.get(c).addAll(dev.arsmisc.item.EnchantersFieldItem.directSpell(caster.getSpell(c)).unsafeList());
        }
    }
    private void select(int selected) {
        channel=selected;send(2+channel);
        radius.visible=radius.active=channel==1;
        radiusApply.visible=radiusApply.active=channel==1;
        if(channel==0) {
            if(getFocused()==radius)setFocused(null);
            radius.setFocused(false);
        }
        interval.setValue(Integer.toString(menu.interval(channel)>0?menu.interval(channel):channel==0?30:1));
        soundChannel=-1;rebuildPalette();
    }
    private List<AbstractSpellPart> available() {
        if(minecraft==null||minecraft.player==null)return List.of();
        var cap=CapabilityRegistry.getPlayerDataCap(minecraft.player);
        var known=new HashSet<>(GlyphRegistry.getDefaultStartingSpells());
        if(cap!=null)known.addAll(cap.getKnownGlyphs());
        String query=search.getValue().toLowerCase(Locale.ROOT);
        return GlyphRegistry.getSpellpartMap().values().stream()
                .filter(p->p.isEnabled()&&p.shouldShowInSpellBook()&&!(p instanceof AbstractCastMethod))
                .filter(p->minecraft.player.isCreative()||known.contains(p))
                .filter(p->GlyphSearch.matches(p.getLocaleName(),p.getRegistryName().toString(),query))
                .sorted(Comparator.comparing(AbstractSpellPart::getTypeIndex).thenComparing(AbstractSpellPart::getLocaleName)).toList();
    }
    private int maxPage() {return Math.max(0,(available().size()-1)/GLYPHS_PER_PAGE);}
    private void rebuildPalette() {
        dynamic.forEach(this::removeWidget);dynamic.clear();
        boolean editor=soundChannel<0;
        search.visible=editor;paletteControls.forEach(b->b.visible=editor);
        if(soundChannel>=0){buildSounds();return;}
        var all=available();page=Math.min(page,Math.max(0,(all.size()-1)/GLYPHS_PER_PAGE));
        for(int i=page*GLYPHS_PER_PAGE;i<Math.min(all.size(),page*GLYPHS_PER_PAGE+GLYPHS_PER_PAGE);i++) {
            int position=i-page*GLYPHS_PER_PAGE;var glyph=all.get(i);
            var b=new GlyphCell(leftPos+14+(position%10)*24,topPos+31+(position/10)*22,glyph,()->{
                if(dev.arsmisc.spell.MarbleSpellValidation.canAppend(drafts.get(channel),channel,glyph)){drafts.get(channel).add(glyph);dirty[channel]=true;}
            });
            dynamic.add(addRenderableWidget(b));
        }
    }
    private void openSounds(int c) {
        soundChannel=c;soundPage=0;rebuildPalette();
    }
    private void buildSounds() {
        var sounds=SpellSoundRegistry.getSpellSounds();
        dynamic.add(button(text("back"),14,35,58,18,()->{soundChannel=-1;rebuildPalette();}));
        dynamic.add(arrow(false,202,35,()->{soundPage=Math.max(0,soundPage-1);rebuildPalette();}));
        dynamic.add(arrow(true,229,35,()->{soundPage=Math.min(Math.max(0,(sounds.size()-1)/10),soundPage+1);rebuildPalette();}));
        for(int i=soundPage*10;i<Math.min(sounds.size(),soundPage*10+10);i++) {
            int index=i,position=i-soundPage*10;var sound=sounds.get(i);
            var b=button(Component.literal(font.plainSubstrByWidth(sound.getSoundName().getString(),104)),14+(position%2)*122,60+(position/2)*27,118,23,
                    ()->send(20000+soundChannel*1000+index));
            b.setTooltip(Tooltip.create(sound.getSoundName()));dynamic.add(b);
        }
    }
    private void save() {
        PacketDistributor.sendToServer(new RealityMarbleEditPayload(menu.containerId,channel,drafts.get(channel).stream().map(AbstractSpellPart::getRegistryName).toList()));
    }
    @Override protected void containerTick() {
        super.containerTick();refreshDrafts();
        if(!initialized&&menu.radiusSetting()>0){radius.setValue(Double.toString(menu.radiusSetting()/10.0));interval.setValue(Integer.toString(menu.interval(channel)));initialized=true;}
        toggle.setMessage(text(menu.enabled()?"enabled":"paused"));
        toggle.setTooltip(Tooltip.create(text("upkeep",menu.radiusSetting()/10.0)));
        clear.active=soundChannel<0;
        var errors=dev.arsmisc.spell.MarbleSpellValidation.errors(drafts.get(channel),channel);
        save.active=soundChannel<0&&errors.isEmpty();
        save.setTooltip(errors.isEmpty()?null:Tooltip.create(errors.getFirst().makeTextComponentExisting()));
        String signature=search.getValue()+":"+soundChannel;
        if(!signature.equals(paletteSignature)){paletteSignature=signature;page=0;rebuildPalette();}
    }
    private void panel(GuiGraphics g,int x,int y,int w,int h,boolean selected) {
        if (!selected) return;
        int color=0xFFB99B46;
        g.fill(leftPos+x,topPos+y,leftPos+x+w,topPos+y+1,color);
        g.fill(leftPos+x,topPos+y+h-1,leftPos+x+w,topPos+y+h,color);
        g.fill(leftPos+x,topPos+y,leftPos+x+1,topPos+y+h,color);
        g.fill(leftPos+x+w-1,topPos+y,leftPos+x+w,topPos+y+h,color);
    }
    @Override protected void renderBg(GuiGraphics g,float partialTick,int mouseX,int mouseY) {
        // Widen the editing page while keeping the native binding between the two sections.
        g.blit(BOOK,leftPos,topPos,270,imageHeight,0,0,145,188,290,188);
        g.blit(BOOK,leftPos+270,topPos,imageWidth-270,imageHeight,145,0,145,188,290,188);
        if(soundChannel<0) {
            for(int c=0;c<2;c++) {
                panel(g,11,SPELL_ROW_TOP+c*SPELL_ROW_SPACING,248,24,c==channel);
                var invalid=dev.arsmisc.spell.MarbleSpellValidation.errors(drafts.get(c),c).stream()
                        .map(error->error.getPosition()-1).collect(java.util.stream.Collectors.toSet());
                for(int i=0;i<10;i++) {
                    int x=leftPos+15+i*24,y=topPos+SPELL_ROW_TOP+4+c*SPELL_ROW_SPACING;
                    g.blit(GLYPH_SLOT,x-2,y-2,0,0,22,20,22,20);
                    if(i<drafts.get(c).size())RenderUtils.drawSpellPart(drafts.get(c).get(i),g,x+1,y+1,16,false);
                    if(invalid.contains(i))g.fill(x,y,x+18,y+18,0x77FF3333);
                }
            }
        }
    }
    @Override protected void renderLabels(GuiGraphics g,int mouseX,int mouseY) {
        g.drawString(font,text(channel==0?"self":"others"),280,18,INK,false);
        g.drawString(font,text("seconds"),280,57,INK,false);
        if(channel==1)g.drawString(font,text("radius"),280,119,INK,false);
        if(soundChannel>=0) {
            g.drawString(font,text("start_sound"),14,16,INK,false);
        } else {
            for(int c=0;c<2;c++) {
                String label=text(c==0?"self":"others").getString()+(dirty[c]?" *":"");
                g.drawString(font,font.plainSubstrByWidth(label,244),14,SPELL_ROW_TOP-10+c*SPELL_ROW_SPACING,INK,false);
            }
        }
    }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float partialTick) {
        super.render(g,mouseX,mouseY,partialTick);
        if(soundChannel<0) for(int c=0;c<2;c++) for(int i=0;i<drafts.get(c).size();i++) {
            int x=leftPos+15+i*24,y=topPos+SPELL_ROW_TOP+4+c*SPELL_ROW_SPACING;
            if(mouseX>=x&&mouseX<x+18&&mouseY>=y&&mouseY<y+18)g.renderTooltip(font,Component.literal(drafts.get(c).get(i).getLocaleName()).append(" · ").append(text("remove")),mouseX,mouseY);
        }
        renderTooltip(g,mouseX,mouseY);
    }
    @Override public boolean mouseClicked(double x,double y,int button) {
        if(soundChannel<0) for(int c=0;c<2;c++) if(y>=topPos+SPELL_ROW_TOP+c*SPELL_ROW_SPACING&&y<topPos+SPELL_ROW_TOP+24+c*SPELL_ROW_SPACING&&x>=leftPos+11&&x<leftPos+259) {
            if(c!=channel){select(c);return true;}
            int index=(int)(x-leftPos-15)/24;
            if(button==1&&index>=0&&index<drafts.get(c).size()){drafts.get(c).remove(index);dirty[c]=true;}
            return true;
        }
        return super.mouseClicked(x,y,button);
    }
    @Override public boolean keyPressed(int key,int scan,int modifiers) {
        if(key!=256)for(var field:List.of(search,interval,radius))if(field.visible&&field.isFocused())return field.keyPressed(key,scan,modifiers);
        return super.keyPressed(key,scan,modifiers);
    }
    private final class GlyphCell extends Button {
        private final AbstractSpellPart glyph;
        GlyphCell(int x,int y,AbstractSpellPart glyph,Runnable action) {
            super(x,y,22,21,Component.literal(glyph.getLocaleName()),b->action.run(),DEFAULT_NARRATION);
            this.glyph=glyph;setTooltip(Tooltip.create(Component.literal(glyph.getLocaleName())));
        }
        @Override protected void renderWidget(GuiGraphics g,int mouseX,int mouseY,float partialTick) {
            active=dev.arsmisc.spell.MarbleSpellValidation.canAppend(drafts.get(channel),channel,glyph);
            if(isHoveredOrFocused())g.fill(getX()-1,getY()-1,getX()+width+1,getY()+height+1,0xFFD2AE65);
            g.blit(GLYPH_SLOT,getX(),getY(),0,0,22,20,22,20);
            RenderUtils.drawSpellPart(glyph,g,getX()+3,getY()+2,16,false);
            if(!active)g.fill(getX(),getY(),getX()+width,getY()+height,0x88979797);
        }
    }
    private final class PageArrow extends Button {
        private final net.minecraft.resources.ResourceLocation normal, hover;
        PageArrow(int x,int y,boolean next,Runnable action) {
            super(x,y,23,18,text(next?"next_page":"previous_page"),b->action.run(),DEFAULT_NARRATION);
            String path="textures/gui/documentation/doc_button_next_page_"+(next?"right":"left");
            normal=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("ars_nouveau",path+".png");
            hover=net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("ars_nouveau",path+"_hover.png");
            setTooltip(Tooltip.create(getMessage()));
        }
        @Override protected void renderWidget(GuiGraphics g,int mouseX,int mouseY,float partialTick) {
            g.blit(isHoveredOrFocused()?hover:normal,getX()+4,getY()+5,0,0,14,8,14,8);
        }
    }
}
