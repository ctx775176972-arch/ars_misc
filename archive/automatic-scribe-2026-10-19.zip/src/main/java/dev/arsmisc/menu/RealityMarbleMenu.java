package dev.arsmisc.menu;

import com.hollingsworth.arsnouveau.api.registry.SpellSoundRegistry;
import com.hollingsworth.arsnouveau.api.sound.ConfiguredSpellSound;
import dev.arsmisc.item.RealityMarbleItem;
import dev.arsmisc.registry.ModMenus;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.*;
import net.minecraft.world.inventory.*;
import net.minecraft.world.item.ItemStack;
import com.hollingsworth.arsnouveau.api.ArsNouveauAPI;
import com.hollingsworth.arsnouveau.api.registry.GlyphRegistry;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.method.MethodTouch;
import com.hollingsworth.arsnouveau.setup.registry.CapabilityRegistry;
import net.minecraft.resources.ResourceLocation;
import java.util.*;

/** All changes are authorized against the exact stack which opened this menu. */
public final class RealityMarbleMenu extends AbstractContainerMenu {
    private final InteractionHand hand;
    private final ItemStack openedStack;
    private final Player owner;
    private final ContainerData data;
    public RealityMarbleMenu(int id, Inventory inv, RegistryFriendlyByteBuf buf) { this(id, inv, buf.readEnum(InteractionHand.class)); }
    public RealityMarbleMenu(int id, Inventory inv, InteractionHand hand) {
        super(ModMenus.REALITY_MARBLE.get(), id);
        this.hand = hand; owner = inv.player; openedStack = inv.player.getItemInHand(hand);
        data = inv.player.level().isClientSide ? new SimpleContainerData(4) : new ContainerData() {
            public int get(int i) { return switch (i) {
                case 0 -> RealityMarbleItem.enabled(openedStack) ? 1 : 0;
                case 1 -> RealityMarbleItem.radiusSetting(openedStack);
                default -> RealityMarbleItem.interval(openedStack, i - 2);
            }; }
            public void set(int i, int v) { }
            public int getCount() { return 4; }
        };
        addDataSlots(data);
    }

    public ItemStack stack() {
        // Inventory synchronization replaces client stacks; the server retains the identity-bound reference.
        return owner.level().isClientSide && owner.getItemInHand(hand).getItem() instanceof RealityMarbleItem
                ? owner.getItemInHand(hand) : openedStack;
    }
    public boolean enabled() { return data.get(0) != 0; }
    public int radiusSetting() { return data.get(1); }
    public int interval(int channel) { return data.get(channel + 2); }
    @Override public boolean stillValid(Player player) {
        return player.isAlive() && (player.level().isClientSide || player.getItemInHand(hand) == openedStack)
                && player.getItemInHand(hand).getItem() instanceof RealityMarbleItem;
    }
    @Override public void clicked(int slotId, int button, ClickType type, Player player) { }
    @Override public boolean clickMenuButton(Player player, int button) {
        if (player.level().isClientSide || !stillValid(player)) return false;
        var item = (RealityMarbleItem) openedStack.getItem();
        if (button == 1) RealityMarbleItem.setEnabled(openedStack, !RealityMarbleItem.enabled(openedStack));
        else if (button == 2 || button == 3) {
            item.getSpellCaster(openedStack).setCurrentSlot(button - 2).saveToStack(openedStack);
        } else if (button == 12) {
            var caster=item.getSpellCaster(openedStack);
            var sounds=SpellSoundRegistry.getSpellSounds();
            if(sounds.isEmpty())return false;
            int index=sounds.indexOf(caster.getSound(2).getSound());
            caster.setSound(new ConfiguredSpellSound(sounds.get((index+1)%sounds.size())),2).saveToStack(openedStack);
        } else if (button >= 22000 && button < 23000) {
            int channel = (button - 20000) / 1000, index = (button - 20000) % 1000;
            var sounds = SpellSoundRegistry.getSpellSounds();
            if (index >= sounds.size()) return false;
            item.getSpellCaster(openedStack).setSound(new ConfiguredSpellSound(sounds.get(index)), channel).saveToStack(openedStack);
        } else if (button >= 1001 && button <= 4600) RealityMarbleItem.setInterval(openedStack, 0, button - 1000);
        else if (button >= 5001 && button <= 8600) RealityMarbleItem.setInterval(openedStack, 1, button - 5000);
        else if (button >= 10010 && button <= 10160) RealityMarbleItem.setRadius(openedStack, button - 10000);
        else return false;
        player.getInventory().setChanged(); player.inventoryMenu.broadcastChanges(); broadcastChanges();
        return true;
    }
    public boolean saveSpell(Player player, int channel, List<ResourceLocation> ids) {
        if (player.level().isClientSide || !stillValid(player) || channel < 0 || channel > 1 || ids.size() > 10) return false;
        var cap = CapabilityRegistry.getPlayerDataCap(player);
        var parts = new ArrayList<AbstractSpellPart>();
        for (var id : ids) {
            var part = GlyphRegistry.getSpellPart(id);
            if (part == null || !part.isEnabled() || part instanceof AbstractCastMethod || !part.shouldShowInSpellBook()) return false;
            if (!player.isCreative() && !GlyphRegistry.getDefaultStartingSpells().contains(part) && (cap == null || !cap.knowsGlyph(part))) return false;
            parts.add(part);
        }
        if (!dev.arsmisc.spell.MarbleSpellValidation.errors(parts,channel).isEmpty()) return false;
        var caster = ((RealityMarbleItem) openedStack.getItem()).getSpellCaster(openedStack);
        var spell = RealityMarbleItem.normalize(caster.getSpell(channel).setRecipe(parts), channel);
        caster.setSpell(spell, channel).saveToStack(openedStack);
        player.getInventory().setChanged(); player.inventoryMenu.broadcastChanges(); broadcastChanges();
        return true;
    }
    @Override public ItemStack quickMoveStack(Player player, int index) { return ItemStack.EMPTY; }
}
