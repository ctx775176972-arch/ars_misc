package dev.arsmisc.network;

import dev.arsmisc.ArsMiscMod;
import dev.arsmisc.menu.RealityMarbleMenu;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import java.util.*;

@EventBusSubscriber(modid = ArsMiscMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public record RealityMarbleEditPayload(int menuId, int channel, List<ResourceLocation> glyphs) implements CustomPacketPayload {
    public static final Type<RealityMarbleEditPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(ArsMiscMod.MOD_ID, "edit_reality_marble"));
    public static final StreamCodec<RegistryFriendlyByteBuf, RealityMarbleEditPayload> CODEC = new StreamCodec<>() {
        public RealityMarbleEditPayload decode(RegistryFriendlyByteBuf buf) {
            int menu = buf.readVarInt(), channel = buf.readVarInt(), count = buf.readVarInt();
            if (count < 0 || count > 10) throw new io.netty.handler.codec.DecoderException("Invalid marble glyph count");
            var ids = new ArrayList<ResourceLocation>(count);
            for (int i = 0; i < count; i++) ids.add(buf.readResourceLocation());
            return new RealityMarbleEditPayload(menu, channel, List.copyOf(ids));
        }
        public void encode(RegistryFriendlyByteBuf buf, RealityMarbleEditPayload payload) {
            buf.writeVarInt(payload.menuId); buf.writeVarInt(payload.channel); buf.writeVarInt(payload.glyphs.size());
            payload.glyphs.forEach(buf::writeResourceLocation);
        }
    };
    @Override public Type<? extends CustomPacketPayload> type() { return TYPE; }
    @SubscribeEvent public static void register(RegisterPayloadHandlersEvent event) {
        event.registrar("1").playToServer(TYPE, CODEC, (payload, context) -> context.enqueueWork(() -> {
            var player = context.player();
            if (player.containerMenu instanceof RealityMarbleMenu menu && menu.containerId == payload.menuId) {
                boolean saved = menu.saveSpell(player, payload.channel, payload.glyphs);
                player.displayClientMessage(Component.translatable("gui.ars_misc.marble." + (saved ? "saved" : "invalid")), true);
            }
        }));
    }
}
