package dev.arsmisc.item;

import com.hollingsworth.arsnouveau.api.item.*;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.api.registry.SpellCasterRegistry;
import com.hollingsworth.arsnouveau.common.spell.method.MethodSelf;
import com.hollingsworth.arsnouveau.setup.registry.*;
import dev.arsmisc.ArsMiscMod;
import dev.arsmisc.menu.RealityMarbleMenu;
import dev.arsmisc.spell.FieldSpellResolver;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.item.component.*;
import net.minecraft.world.level.Level;
import top.theillusivec4.curios.api.*;
import java.util.*;

/** Two independent spell channels with a separately paid, radius-based upkeep. */
public final class RealityMarbleItem extends ArsNouveauCurio implements ICasterTool {
    public RealityMarbleItem() { super(new Properties().stacksTo(1)); }
    public static CompoundTag data(ItemStack stack) {
        return stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
    }
    public static boolean enabled(ItemStack stack) { return data(stack).getBoolean("marble_enabled"); }
    public static void setEnabled(ItemStack stack, boolean value) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> {
            tag.putBoolean("marble_enabled", value);
            tag.remove("marble_paid");
        });
    }
    public static int radiusSetting(ItemStack stack) {
        var tag = data(stack);
        return tag.contains("marble_radius") ? Math.clamp(tag.getInt("marble_radius"), 10, 160) : 80;
    }
    public static void setRadius(ItemStack stack, int value) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putInt("marble_radius", Math.clamp(value, 10, 160)));
    }
    public static double upkeep(ItemStack stack) { return radiusSetting(stack) / 10.0; }
    public static int interval(ItemStack stack, int channel) {
        var tag = data(stack); String key = "marble_interval_" + channel;
        return tag.contains(key) ? Math.clamp(tag.getInt(key), 1, 3600) : channel == 0 ? 30 : 1;
    }
    public static void setInterval(ItemStack stack, int channel, int value) {
        if (channel < 0 || channel > 1) return;
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putInt("marble_interval_" + channel, Math.clamp(value, 1, 3600)));
    }
    @Override public AbstractCaster<?> getSpellCaster(ItemStack stack) {
        return stack.getOrDefault(DataComponentRegistry.SPELL_CASTER.get(), new SpellCaster().setMaxSlots(3));
    }
    public static Spell normalize(Spell spell, int channel) {
        var parts = new ArrayList<AbstractSpellPart>(spell.unsafeList());
        if (!parts.isEmpty() && parts.getFirst() instanceof AbstractCastMethod) parts.removeFirst();
        if (parts.isEmpty()) return new Spell();
        if (channel == 0) parts.addFirst(MethodSelf.INSTANCE);
        return spell.setRecipe(parts);
    }
    @Override public boolean isScribedSpellValid(AbstractCaster<?> caster, Player player, InteractionHand hand, ItemStack stack, Spell spell) {
        return !normalize(spell, caster.getCurrentSlot()).isEmpty();
    }
    @Override public void scribeModifiedSpell(AbstractCaster<?> caster, Player player, InteractionHand hand, ItemStack stack, Spell.Mutable spell) {
        spell.recipe = new ArrayList<>(normalize(spell.immutable(), caster.getCurrentSlot()).unsafeList());
    }
    public static ItemStack equipped(Player player) {
        return CuriosApi.getCuriosInventory(player).flatMap(inv -> inv.findCurios(s -> s.getItem() instanceof RealityMarbleItem).stream()
                .filter(result -> inv.isSlotActive(result.slotContext().identifier(), result.slotContext().index())).findFirst())
                .map(SlotResult::stack).orElse(ItemStack.EMPTY);
    }
    public static boolean toggle(Player player) {
        if (player.level().isClientSide || !player.isAlive() || player.isSpectator()) return false;
        var stack = equipped(player); if (stack.isEmpty()) return false;
        setEnabled(stack, !enabled(stack));
        player.displayClientMessage(Component.translatable("gui.ars_misc.marble." + (enabled(stack) ? "enabled" : "paused")), true);
        return true;
    }
    @Override public boolean canEquipFromUse(SlotContext context, ItemStack stack) { return false; }
    @Override public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        var stack = player.getItemInHand(hand);
        if (player instanceof ServerPlayer server) server.openMenu(new SimpleMenuProvider((id, inv, p) ->
                new RealityMarbleMenu(id, inv, hand), stack.getHoverName()), buf -> buf.writeEnum(hand));
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
    @Override public void curioTick(SlotContext slot, ItemStack stack) {
        if (slot.cosmetic() || !(slot.entity() instanceof Player player) || player.level().isClientSide
                || player.tickCount % 20 != 0 || !player.isAlive() || player.isSpectator() || !enabled(stack)) return;
        // Only one marble may run, even when a pack supplies extra generic Curios slots.
        if (equipped(player) != stack) return;
        long now = player.level().getGameTime();
        String gate = "ars_misc:marble_paid";
        long last = player.getPersistentData().getLong(gate);
        if (player.getPersistentData().contains(gate) && last <= now && now - last < 20) return;
        var mana = CapabilityRegistry.getMana(player);
        if (mana == null || mana.getCurrentMana() < upkeep(stack)) {
            setEnabled(stack, false);
            player.displayClientMessage(Component.translatable("gui.ars_misc.marble.no_mana"), true);
            return;
        }
        mana.removeMana(upkeep(stack));
        player.getPersistentData().putLong(gate, now);
        boolean starting = !data(stack).contains("marble_paid") || data(stack).getLong("marble_paid") > now
                || now - data(stack).getLong("marble_paid") > 40;
        CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putLong("marble_paid", now));
        var caster = getSpellCaster(stack);
        if (starting) caster.getSound(2).playSound(player.level(), player.position());
        try {
            for (int channel = 0; channel < 2; channel++) {
                String key = "marble_next_" + channel;
                long next = data(stack).getLong(key);
                if (next > now && next <= now + 72000) continue;
                Spell spell = normalize(caster.getSpell(channel), channel);
                if (spell.isEmpty() || !dev.arsmisc.spell.MarbleSpellValidation.errors(EnchantersFieldItem.directSpell(spell).unsafeList(),channel).isEmpty()) continue;
                int index = channel;
                CustomData.update(DataComponents.CUSTOM_DATA, stack, t -> t.putLong(key, now + interval(stack, index) * 20L));
                var context = SpellContext.fromEntity(spell, player, stack).withColors(caster.getColor(channel));
                boolean cast = false;
                if (channel == 0) {
                    cast = new SpellResolver(context).withSilent(true).onCast(stack, player.level());
                } else {
                    // Reuse the field's native filters and ownership exclusions, with this item's radius.
                    var proxy = ArsMiscMod.ENCHANTERS_FIELD.get().getDefaultInstance();
                    EnchantersFieldItem.setRadius(proxy, radiusSetting(stack));
                    for (var target : ArsMiscMod.ENCHANTERS_FIELD.get().targets(player, proxy)) {
                        if (!enabled(stack)) break;
                        if (!target.isAlive()) continue;
                        var resolver = new FieldSpellResolver(SpellContext.fromEntity(spell, player, stack).withColors(caster.getColor(channel)));
                        resolver.withSilent(true);
                        cast |= resolver.castOnTarget(player, target);
                    }
                    if(cast) com.hollingsworth.arsnouveau.common.spell.method.MethodTouch.INSTANCE
                            .playResolveSound(context,player.level(),player.position());
                }
            }
        } catch (RuntimeException exception) {
            setEnabled(stack, false);
            ArsMiscMod.LOGGER.error("Paused Reality Marble after a spell error", exception);
            player.displayClientMessage(Component.translatable("gui.ars_misc.marble.error"), true);
        }
    }
    @Override public void appendHoverText(ItemStack stack, TooltipContext context, List<Component> lines, TooltipFlag flag) {
        super.appendHoverText(stack, context, lines, flag);
        lines.add(Component.translatable("gui.ars_misc.marble.help"));
        lines.add(Component.translatable("gui.ars_misc.marble.upkeep", upkeep(stack)));
        lines.add(Component.translatable(enabled(stack) ? "gui.ars_misc.watch.enabled" : "gui.ars_misc.watch.paused"));
    }
}
