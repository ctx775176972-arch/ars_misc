package dev.arsmisc.spell;

import com.hollingsworth.arsnouveau.api.ArsNouveauAPI;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.method.*;
import java.util.*;

/** Uses the spellbook's crafting rules, without imposing an item/book tier. */
public final class MarbleSpellValidation {
    private MarbleSpellValidation() { }
    public static List<SpellValidationError> errors(List<AbstractSpellPart> effects, int channel) {
        if (effects.isEmpty()) return List.of();
        var parts=new ArrayList<AbstractSpellPart>(effects);
        parts.addFirst(channel==0?MethodSelf.INSTANCE:MethodTouch.INSTANCE);
        return ArsNouveauAPI.getInstance().getSpellCraftingSpellValidator().validate(parts);
    }
    public static boolean canAppend(List<AbstractSpellPart> effects, int channel, AbstractSpellPart glyph) {
        if(effects.size()>=10 || glyph instanceof AbstractCastMethod)return false;
        var candidate=new ArrayList<AbstractSpellPart>(effects);candidate.add(glyph);
        return errors(candidate,channel).stream().noneMatch(error->error.getPosition()>=candidate.size());
    }
}
