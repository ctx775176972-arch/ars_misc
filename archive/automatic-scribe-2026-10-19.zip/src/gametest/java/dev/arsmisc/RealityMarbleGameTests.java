package dev.arsmisc;

import com.hollingsworth.arsnouveau.api.registry.SpellCasterRegistry;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.effect.*;
import com.hollingsworth.arsnouveau.common.spell.method.*;
import com.hollingsworth.arsnouveau.setup.registry.*;
import dev.arsmisc.item.RealityMarbleItem;
import dev.arsmisc.menu.RealityMarbleMenu;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.GameType;
import net.neoforged.neoforge.gametest.*;
import top.theillusivec4.curios.api.*;

@GameTestHolder("ars_misc") @PrefixGameTestTemplate(false)
public final class RealityMarbleGameTests {
    private static ItemStack equip(Player player) {
        var stack = ArsMiscMod.REALITY_MARBLE.get().getDefaultInstance();
        CuriosApi.getCuriosInventory(player).orElseThrow().setEquippedCurio("charm", 0, stack);
        stack = RealityMarbleItem.equipped(player);
        RealityMarbleItem.setEnabled(stack, true);
        return stack;
    }
    private static void tick(Player player, ItemStack stack) {
        player.tickCount = 0;
        ArsMiscMod.REALITY_MARBLE.get().curioTick(new SlotContext("charm", player, 0, false, true), stack);
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void upkeepPaidWithoutTargetsAndFailureClosesMarble(GameTestHelper h) {
        var p = h.makeMockPlayer(GameType.SURVIVAL);
        var mana = CapabilityRegistry.getMana(p); mana.setMaxMana(1000); mana.setMana(100);
        var s = equip(p); tick(p, s);
        h.assertTrue(mana.getCurrentMana() == 92 && RealityMarbleItem.enabled(s), "Empty marble must still pay eight mana upkeep");
        tick(p, s);
        h.assertTrue(mana.getCurrentMana() == 92, "Repeated tick double-charged upkeep");
        p.getPersistentData().remove("ars_misc:marble_paid"); mana.setMana(7); tick(p, s);
        h.assertTrue(!RealityMarbleItem.enabled(s) && mana.getCurrentMana() == 7 && !RealityMarbleItem.data(s).contains("marble_paid"), "Insufficient upkeep must close without casting or partial payment");
        h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void channelsHealSelfAndDamageTargetWithIndependentTimers(GameTestHelper h) {
        var p = h.makeMockPlayer(GameType.SURVIVAL); p.setPos(h.absoluteVec(new net.minecraft.world.phys.Vec3(16,2,16))); p.setHealth(5);
        var target = h.spawnWithNoFreeWill(EntityType.COW, 16,2,18);
        var wolf = h.spawnWithNoFreeWill(EntityType.WOLF, 17,2,16); wolf.setTame(true,true); wolf.setOwnerUUID(p.getUUID());
        float wolfHealth = wolf.getHealth(), targetHealth = target.getHealth();
        var mana = CapabilityRegistry.getMana(p); mana.setMaxMana(1000); mana.setMana(1000);
        var s = equip(p);
        new SpellCaster().setMaxSlots(3).setSpell(new Spell(MethodSelf.INSTANCE, EffectHeal.INSTANCE),0)
                .setSpell(new Spell(EffectHarm.INSTANCE),1).saveToStack(s);
        tick(p,s);
        h.assertTrue(p.getHealth() > 5 && target.getHealth() < targetHealth && wolf.getHealth() == wolfHealth, "Self/area channels or pet exclusion failed");
        long now = p.level().getGameTime();
        h.assertTrue(RealityMarbleItem.data(s).getLong("marble_next_0") == now + 600
                && RealityMarbleItem.data(s).getLong("marble_next_1") == now + 20, "Channels share an interval");
        h.assertTrue(mana.getCurrentMana() < 992, "Spell costs did not add to upkeep"); h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void menuScribesBothChannelsAndRejectsReplacementAndInvalidSettings(GameTestHelper h) {
        var p = h.makeMockPlayer(GameType.SURVIVAL);
        var s = ArsMiscMod.REALITY_MARBLE.get().getDefaultInstance();
        p.setItemInHand(InteractionHand.MAIN_HAND,s);
        var book = ItemsRegistry.NOVICE_SPELLBOOK.get().getDefaultInstance();
        SpellCasterRegistry.from(book).setSpell(new Spell(MethodProjectile.INSTANCE,EffectHeal.INSTANCE)).setSpellName("Support").saveToStack(book);
        p.setItemInHand(InteractionHand.OFF_HAND,book);
        var menu = new RealityMarbleMenu(1,p.getInventory(),InteractionHand.MAIN_HAND);
        h.assertTrue(!menu.clickMenuButton(p,4) && !menu.clickMenuButton(p,5), "Removed offhand copy still available");
        var source=SpellCasterRegistry.from(book).getSpell();
        new SpellCaster().setMaxSlots(3).setSpell(RealityMarbleItem.normalize(source,0),0).setSpell(RealityMarbleItem.normalize(source,1),1).saveToStack(s);
        var caster = ArsMiscMod.REALITY_MARBLE.get().getSpellCaster(s);
        h.assertTrue(caster.getSpell(0).getCastMethod() == MethodSelf.INSTANCE && caster.getSpell(1).getCastMethod() == null, "Channel forms were not normalized");
        h.assertTrue(caster.getSpellName(0).equals("Support") && caster.getSpellName(1).equals("Support"), "Spell names lost");
        h.assertTrue(menu.clickMenuButton(p,10160) && RealityMarbleItem.upkeep(s) == 16 && !menu.clickMenuButton(p,10161), "Radius validation failed");
        h.assertTrue(menu.clickMenuButton(p,4600) && menu.clickMenuButton(p,5001) && RealityMarbleItem.interval(s,0) == 3600 && RealityMarbleItem.interval(s,1) == 1, "Interval validation failed");
        h.assertTrue(!menu.clickMenuButton(p,10) && menu.clickMenuButton(p,12), "Native sound selection failed");
        h.assertTrue(menu.clickMenuButton(p,3), "Area scribing channel selection failed");
        p.setItemInHand(InteractionHand.MAIN_HAND, book);
        h.assertTrue(ArsMiscMod.REALITY_MARBLE.get().onScribe(h.getLevel(),net.minecraft.core.BlockPos.ZERO,p,InteractionHand.MAIN_HAND,s), "Native table scribing failed");
        caster = ArsMiscMod.REALITY_MARBLE.get().getSpellCaster(s);
        h.assertTrue(caster.getSpell(0).getCastMethod() == MethodSelf.INSTANCE && caster.getSpell(1).getCastMethod() == null, "Table scribing overwrote the other channel or retained a form");
        p.setItemInHand(InteractionHand.MAIN_HAND,s);
        h.assertTrue(menu.slots.isEmpty() && !menu.clickMenuButton(p,30), "Removed inventory page still available");
        p.setItemInHand(InteractionHand.MAIN_HAND,s.copy());
        h.assertTrue(!menu.clickMenuButton(p,1), "Menu edited replacement stack"); h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void noManaAfterUpkeepSkipsSpellWithoutFreeCasting(GameTestHelper h) {
        var p = h.makeMockPlayer(GameType.SURVIVAL); p.setHealth(5);
        var s = equip(p);
        new SpellCaster().setSpell(new Spell(MethodSelf.INSTANCE,EffectHeal.INSTANCE),0).saveToStack(s);
        var mana = CapabilityRegistry.getMana(p); mana.setMaxMana(1000); mana.setMana(8);
        tick(p,s);
        h.assertTrue(p.getHealth() == 5 && mana.getCurrentMana() == 0 && RealityMarbleItem.enabled(s), "Unaffordable spell cast or upkeep failed");
        h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void editorUsesLearnedGlyphsWithoutBookTierAndPreservesOtherChannel(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);
        var s=ArsMiscMod.REALITY_MARBLE.get().getDefaultInstance();
        p.setItemInHand(InteractionHand.MAIN_HAND,s);
        var menu=new RealityMarbleMenu(1,p.getInventory(),InteractionHand.MAIN_HAND);
        CapabilityRegistry.getPlayerDataCap(p).setKnownGlyphs(java.util.List.of(EffectRegeneration.INSTANCE,EffectHarm.INSTANCE));
        h.assertTrue(menu.saveSpell(p,0,java.util.List.of(EffectRegeneration.INSTANCE.getRegistryName())),"Learned tier-two glyph rejected without a tier-two book");
        h.assertTrue(menu.saveSpell(p,1,java.util.List.of(EffectHarm.INSTANCE.getRegistryName())),"Area edit failed");
        var caster=ArsMiscMod.REALITY_MARBLE.get().getSpellCaster(s);
        h.assertTrue(caster.getSpell(0).getCastMethod()==MethodSelf.INSTANCE && caster.getSpell(0).get(1)==EffectRegeneration.INSTANCE
                && caster.getSpell(1).getCastMethod()==null && caster.getSpell(1).get(0)==EffectHarm.INSTANCE,"Editor changed another channel or forced the wrong cast form");
        h.assertTrue(menu.saveSpell(p,0,java.util.List.of()),"Could not clear channel");
        h.assertTrue(ArsMiscMod.REALITY_MARBLE.get().getSpellCaster(s).getSpell(0).isEmpty(),"Clearing left a Self-only spell");
        h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void editorRejectsUnknownGlyphsInvalidStructureAndMovedItems(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);
        var s=ArsMiscMod.REALITY_MARBLE.get().getDefaultInstance();p.setItemInHand(InteractionHand.MAIN_HAND,s);
        var menu=new RealityMarbleMenu(1,p.getInventory(),InteractionHand.MAIN_HAND);
        CapabilityRegistry.getPlayerDataCap(p).setKnownGlyphs(java.util.List.of());
        h.assertTrue(!menu.saveSpell(p,0,java.util.List.of(EffectFlight.INSTANCE.getRegistryName())),"Unknown glyph accepted");
        h.assertTrue(!menu.saveSpell(p,1,java.util.List.of(MethodProjectile.INSTANCE.getRegistryName())),"Cast method accepted in an effect row");
        h.assertTrue(!menu.saveSpell(p,2,java.util.List.of()) && !menu.saveSpell(p,0,java.util.Collections.nCopies(11,EffectHarm.INSTANCE.getRegistryName())),"Invalid channel or oversized recipe accepted");
        h.assertTrue(menu.slots.isEmpty() && !menu.clickMenuButton(p,30), "Removed inventory page still available");
        p.setItemInHand(InteractionHand.MAIN_HAND,s.copy());
        h.assertTrue(!menu.saveSpell(p,0,java.util.List.of()),"Editor modified a replacement item");h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void selfUsesNativeTimelineSoundWithoutExtraPlayback(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setHealth(5);
        var s=equip(p);
        var old=new com.hollingsworth.arsnouveau.api.sound.ConfiguredSpellSound(new com.hollingsworth.arsnouveau.api.sound.SpellSound(
                net.minecraft.core.Holder.direct(net.minecraft.sounds.SoundEvents.ANVIL_LAND),net.minecraft.network.chat.Component.literal("Old"),
                net.minecraft.resources.ResourceLocation.withDefaultNamespace("old")));
        var chosen=new com.hollingsworth.arsnouveau.api.sound.ConfiguredSpellSound(new com.hollingsworth.arsnouveau.api.sound.SpellSound(
                net.minecraft.core.Holder.direct(net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP),net.minecraft.network.chat.Component.literal("New"),
                net.minecraft.resources.ResourceLocation.withDefaultNamespace("new")));
        var type=com.hollingsworth.arsnouveau.api.registry.ParticleTimelineRegistry.SELF_TIMELINE.get();
        var timeline=new com.hollingsworth.arsnouveau.api.particle.timelines.SelfTimeline();
        timeline.resolveSound=new com.hollingsworth.arsnouveau.api.particle.configurations.properties.SoundProperty(old);
        var spell=new Spell(MethodSelf.INSTANCE,EffectHeal.INSTANCE).withTimeline(new com.hollingsworth.arsnouveau.api.particle.timelines.TimelineMap().put(type,timeline));
        new SpellCaster().setMaxSlots(3).setSpell(spell,0).setSound(chosen,0)
                .setSound(com.hollingsworth.arsnouveau.api.sound.ConfiguredSpellSound.EMPTY,2).saveToStack(s);
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(1000);
        int[] counts={0,0};
        java.util.function.Consumer<net.neoforged.neoforge.event.PlayLevelSoundEvent.AtPosition> listener=event->{
            if(event.getLevel()!=p.level())return;
            var id=event.getSound().value().getLocation();
            if(id.equals(net.minecraft.sounds.SoundEvents.ANVIL_LAND.getLocation()))counts[0]++;
            if(id.equals(net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP.getLocation()))counts[1]++;
        };
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(listener);
        try {tick(p,s);} finally {net.neoforged.neoforge.common.NeoForge.EVENT_BUS.unregister(listener);}
        h.assertTrue(counts[0]==1 && counts[1]==0,"Expected only the native timeline sound; native="+counts[0]+", new="+counts[1]);
        h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void craftingRulesEnforcePerEffectAmplifyLimitsOnBothChannels(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.CREATIVE);
        var s=ArsMiscMod.REALITY_MARBLE.get().getDefaultInstance();p.setItemInHand(InteractionHand.MAIN_HAND,s);
        var menu=new RealityMarbleMenu(1,p.getInventory(),InteractionHand.MAIN_HAND);
        var amp=com.hollingsworth.arsnouveau.common.spell.augment.AugmentAmplify.INSTANCE;
        var legal=java.util.List.<AbstractSpellPart>of(EffectHarm.INSTANCE,amp,amp);
        for(int channel=0;channel<2;channel++) {
            h.assertTrue(menu.saveSpell(p,channel,legal.stream().map(AbstractSpellPart::getRegistryName).toList()),"Legal Harm Amplify count rejected");
            h.assertTrue(!dev.arsmisc.spell.MarbleSpellValidation.canAppend(legal,channel,amp),"Editor allowed a third Amplify on Harm");
            h.assertTrue(!menu.saveSpell(p,channel,java.util.List.of(EffectHarm.INSTANCE.getRegistryName(),amp.getRegistryName(),amp.getRegistryName(),amp.getRegistryName())),"Server accepted excessive Amplify");
        }
        var regen=java.util.List.<AbstractSpellPart>of(EffectRegeneration.INSTANCE,amp);
        h.assertTrue(menu.saveSpell(p,0,regen.stream().map(AbstractSpellPart::getRegistryName).toList()),"Regeneration Amplify I rejected");
        h.assertTrue(!dev.arsmisc.spell.MarbleSpellValidation.canAppend(regen,0,amp),"Regeneration ignored its one-Amplify limit");
        h.assertTrue(!menu.saveSpell(p,0,java.util.List.of(EffectRegeneration.INSTANCE.getRegistryName(),amp.getRegistryName(),amp.getRegistryName())),"Server accepted a second Regeneration Amplify");
        h.assertTrue(!dev.arsmisc.spell.MarbleSpellValidation.canAppend(java.util.List.of(),0,amp),"Augment accepted without a compatible preceding glyph");
        h.succeed();
    }
    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void areaUsesNativeTouchTimelineSoundOncePerCycle(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new net.minecraft.world.phys.Vec3(16,2,16)));
        h.spawnWithNoFreeWill(EntityType.COW,16,2,18);h.spawnWithNoFreeWill(EntityType.COW,16,2,19);
        var s=equip(p);
        var sound=new com.hollingsworth.arsnouveau.api.sound.ConfiguredSpellSound(new com.hollingsworth.arsnouveau.api.sound.SpellSound(
                net.minecraft.core.Holder.direct(net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP),net.minecraft.network.chat.Component.literal("Native Touch"),
                net.minecraft.resources.ResourceLocation.withDefaultNamespace("touch")));
        var type=com.hollingsworth.arsnouveau.api.registry.ParticleTimelineRegistry.TOUCH_TIMELINE.get();
        var timeline=new com.hollingsworth.arsnouveau.api.particle.timelines.TouchTimeline();
        timeline.resolveSound=new com.hollingsworth.arsnouveau.api.particle.configurations.properties.SoundProperty(sound);
        new SpellCaster().setMaxSlots(3).setSpell(new Spell(EffectHarm.INSTANCE)
                .withTimeline(new com.hollingsworth.arsnouveau.api.particle.timelines.TimelineMap().put(type,timeline)),1)
                .setSound(com.hollingsworth.arsnouveau.api.sound.ConfiguredSpellSound.EMPTY,2).saveToStack(s);
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(1000);int[] count={0};
        java.util.function.Consumer<net.neoforged.neoforge.event.PlayLevelSoundEvent.AtPosition> listener=event->{
            if(event.getLevel()==p.level()&&event.getSound().value().getLocation().equals(net.minecraft.sounds.SoundEvents.EXPERIENCE_ORB_PICKUP.getLocation()))count[0]++;
        };
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(listener);
        try {tick(p,s);} finally {net.neoforged.neoforge.common.NeoForge.EVENT_BUS.unregister(listener);}
        h.assertTrue(count[0]==1,"Area cycle repeated or dropped native Touch sound: "+count[0]);h.succeed();
    }
}
