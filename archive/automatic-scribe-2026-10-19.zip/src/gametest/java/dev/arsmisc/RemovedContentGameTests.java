package dev.arsmisc;

import com.hollingsworth.arsnouveau.api.registry.GlyphRegistry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.GameTest;
import net.minecraft.gametest.framework.GameTestHelper;
import net.minecraft.resources.ResourceLocation;
import net.neoforged.neoforge.gametest.GameTestHolder;
import net.neoforged.neoforge.gametest.PrefixGameTestTemplate;

@GameTestHolder("ars_misc") @PrefixGameTestTemplate(false)
public final class RemovedContentGameTests {
    @GameTest(template="empty",templateNamespace="ars_misc")
    public static void archivedSummonsAreAbsentFromRuntimeRegistries(GameTestHelper h) {
        for(var name:java.util.List.of("guardian","warrior")) {
            var entity=ResourceLocation.fromNamespaceAndPath("ars_misc","summoned_"+name);
            var glyph=ResourceLocation.fromNamespaceAndPath("ars_misc","glyph_summon_"+name);
            h.assertTrue(!BuiltInRegistries.ENTITY_TYPE.containsKey(entity),"Archived summon entity is still registered: "+entity);
            h.assertTrue(!BuiltInRegistries.ITEM.containsKey(glyph) && !GlyphRegistry.getSpellpartMap().containsKey(glyph)
                    && !GlyphRegistry.getGlyphItemMap().containsKey(glyph),"Archived summon glyph is still registered: "+glyph);
        }
        h.assertTrue(GlyphRegistry.getSpellPart(EffectLifeSense.INSTANCE.getRegistryName())==EffectLifeSense.INSTANCE,
                "Removing summons broke another glyph registration");
        h.succeed();
    }
}
