package dev.arsmisc;

import dev.arsmisc.item.EnchantersFieldItem;
import dev.arsmisc.item.EnchantersPocketWatchItem;
import dev.arsmisc.menu.EnchantersFieldMenu;
import dev.arsmisc.network.ToggleCastingPayload;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.effect.EffectHarm;
import com.hollingsworth.arsnouveau.common.spell.method.*;
import com.hollingsworth.arsnouveau.setup.registry.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.level.block.Blocks;
import net.neoforged.neoforge.gametest.*;
import top.theillusivec4.curios.api.*;

@GameTestHolder("ars_misc") @PrefixGameTestTemplate(false)
public final class FieldGameTests {
    private static ItemStack field() {
        var s=ArsMiscMod.ENCHANTERS_FIELD.get().getDefaultInstance();
        new SpellCaster().setSpell(new Spell(EffectHarm.INSTANCE)).saveToStack(s);return s;
    }
    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void scribingRemovesFormAndMenuChecksHeldStack(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);var s=field();var item=ArsMiscMod.ENCHANTERS_FIELD.get();
        var book=ItemsRegistry.NOVICE_SPELLBOOK.get().getDefaultInstance();
        com.hollingsworth.arsnouveau.api.registry.SpellCasterRegistry.from(book).setSpell(new Spell(MethodProjectile.INSTANCE,EffectHarm.INSTANCE)).saveToStack(book);
        p.setItemInHand(InteractionHand.MAIN_HAND,book);
        h.assertTrue(item.onScribe(h.getLevel(),BlockPos.ZERO,p,InteractionHand.MAIN_HAND,s),"Scribing failed");
        var spell=item.getSpellCaster(s).getSpell();h.assertTrue(spell.getCastMethod()==null && spell.unsafeList().size()==1 && spell.get(0)==EffectHarm.INSTANCE,"Initial cast form was not removed");
        p.setItemInHand(InteractionHand.MAIN_HAND,s);var menu=new EnchantersFieldMenu(1,p.getInventory(),InteractionHand.MAIN_HAND);
        h.assertTrue(menu.clickMenuButton(p,101) && menu.clickMenuButton(p,10015),"Menu config failed");
        h.assertTrue(EnchantersFieldItem.interval(s)==1 && EnchantersFieldItem.radiusSetting(s)==15,"Wrong config");
        h.assertTrue(!menu.clickMenuButton(p,10161),"Accepted invalid radius");
        p.setItemInHand(InteractionHand.MAIN_HAND,field());h.assertTrue(!menu.clickMenuButton(p,1),"Menu edited replacement item");h.succeed();
    }
    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void noTargetsNoManaAndOwnedTargetsExcluded(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new net.minecraft.world.phys.Vec3(16,2,16)));
        var s=field();var item=ArsMiscMod.ENCHANTERS_FIELD.get();var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(500);
        var wolf=h.spawnWithNoFreeWill(EntityType.WOLF,16,2,17);wolf.setTame(true,true);wolf.setOwnerUUID(p.getUUID());
        h.assertTrue(!EnchantersFieldItem.validTarget(p,wolf) && !EnchantersFieldItem.validTarget(p,p),"Owned target or player accepted");
        // The entity tag allows addon summons without OwnableEntity to be excluded by a datapack.
        p.tickCount=0;double before=mana.getCurrentMana();item.curioTick(new SlotContext("charm",p,0,false,true),s);
        h.assertTrue(mana.getCurrentMana()==before,"No eligible targets consumed mana");h.succeed();
    }
    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void targetedCastingSpendsManaAndDoesNotRequireSight(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new net.minecraft.world.phys.Vec3(16,2,16)));
        var target=h.spawnWithNoFreeWill(EntityType.COW,16,2,18);var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(500);
        h.setBlock(new BlockPos(16,3,17),Blocks.STONE);var item=ArsMiscMod.ENCHANTERS_FIELD.get();var s=field();
        double before=mana.getCurrentMana();float health=target.getHealth();p.tickCount=0;
        item.curioTick(new SlotContext("charm",p,0,false,true),s);
        h.assertTrue(target.getHealth()<health && mana.getCurrentMana()<before,"Native targeted cast failed through wall");
        var unfunded=field();mana.setMana(0);health=target.getHealth();item.curioTick(new SlotContext("charm",p,0,false,true),unfunded);
        h.assertTrue(target.getHealth()==health,"Cast without mana");
        p.getAttribute(Attributes.ENTITY_INTERACTION_RANGE).setBaseValue(5);h.assertTrue(EnchantersFieldItem.radius(p,s)==8,"Default radius depended on reach");
        EnchantersFieldItem.setRadius(s,20);h.assertTrue(EnchantersFieldItem.radius(p,s)==2,"Manual radius not applied");h.succeed();
    }
    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void nativeFiltersStopRightHandEffectsButSpendMana(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);var target=h.spawnWithNoFreeWill(EntityType.COW,1,2,1);
        var filter=new AbstractFilter(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("ars_misc","test_reject"),"Reject") {
            @Override public boolean shouldResolveOnBlock(net.minecraft.world.phys.BlockHitResult hit,net.minecraft.world.level.Level level) { return false; }
            @Override public boolean shouldResolveOnEntity(net.minecraft.world.phys.EntityHitResult hit,net.minecraft.world.level.Level level) { return false; }
        };
        var spell=new Spell(filter,EffectHarm.INSTANCE);
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(500);double before=mana.getCurrentMana();float health=target.getHealth();
        var resolver=new dev.arsmisc.spell.FieldSpellResolver(SpellContext.fromEntity(spell,p,ItemStack.EMPTY));resolver.withSilent(true);resolver.castOnTarget(p,target);
        h.assertTrue(target.getHealth()==health && mana.getCurrentMana()<before,"Filter skipped native cast cost or did not stop Harm");h.succeed();
    }
    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void extendedRadiusCastsBeyondReachAndCapsAtSixteen(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new net.minecraft.world.phys.Vec3(16,2,16)));
        p.getAttribute(Attributes.ENTITY_INTERACTION_RANGE).setBaseValue(3);
        var target=h.spawnWithNoFreeWill(EntityType.COW,28,2,16);
        var outside=h.spawnWithNoFreeWill(EntityType.COW,0,2,0);
        var item=ArsMiscMod.ENCHANTERS_FIELD.get();var s=field();
        h.assertTrue(!item.targets(p,s).contains(target),"Default eight-block radius accepted distant target");
        EnchantersFieldItem.setRadius(s,999);
        h.assertTrue(EnchantersFieldItem.radius(p,s)==16 && item.targets(p,s).contains(target) && !item.targets(p,s).contains(outside),"Maximum radius or reach independence failed");
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(500);
        float health=target.getHealth();double before=mana.getCurrentMana();p.tickCount=0;
        item.curioTick(new SlotContext("charm",p,0,false,true),s);
        h.assertTrue(target.getHealth()<health && mana.getCurrentMana()<before && EnchantersFieldItem.enabled(s),"Direct effect beyond interaction range failed");h.succeed();
    }
    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void togglesOnlyActiveEquippedItems(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);var s=field();p.setItemInHand(InteractionHand.MAIN_HAND,s);
        h.assertTrue(!ToggleCastingPayload.toggle(p) && EnchantersFieldItem.enabled(s),"Held field toggled");
        var inv=CuriosApi.getCuriosInventory(p).orElseThrow();inv.setEquippedCurio("charm",0,s);
        boolean toggled=ToggleCastingPayload.toggle(p);
        h.assertTrue(toggled && !EnchantersFieldItem.enabled(inv.getStacksHandler("charm").orElseThrow().getStacks().getStackInSlot(0)),"Field toggle failed: found="+toggled+", stack="+inv.getStacksHandler("charm").orElseThrow().getStacks().getStackInSlot(0)+", enabled="+EnchantersFieldItem.enabled(inv.getStacksHandler("charm").orElseThrow().getStacks().getStackInSlot(0)));
        h.assertTrue(ToggleCastingPayload.toggle(p) && EnchantersFieldItem.enabled(inv.getStacksHandler("charm").orElseThrow().getStacks().getStackInSlot(0)),"Shared key did not re-enable field");
        var watch=ArsMiscMod.ENCHANTERS_POCKET_WATCH.get().getDefaultInstance();inv.setEquippedCurio("charm",0,watch);
        h.assertTrue(ToggleCastingPayload.toggle(p) && !EnchantersPocketWatchItem.enabled(inv.getStacksHandler("charm").orElseThrow().getStacks().getStackInSlot(0)),"Watch toggle failed");h.succeed();
    }

    @GameTest(template="combat_arena",templateNamespace="ars_misc")
    public static void sharedToggleSynchronizesCastingAccessoriesAndIgnoresInactiveSlots(GameTestHelper h) {
        var player=h.makeMockPlayer(GameType.SURVIVAL);
        var inventory=CuriosApi.getCuriosInventory(player).orElseThrow();
        var handler=inventory.getStacksHandler("charm").orElseThrow();
        handler.grow(2);
        var watch=ArsMiscMod.ENCHANTERS_POCKET_WATCH.get().getDefaultInstance();
        var field=ArsMiscMod.ENCHANTERS_FIELD.get().getDefaultInstance();
        var marble=ArsMiscMod.REALITY_MARBLE.get().getDefaultInstance();
        EnchantersPocketWatchItem.setEnabled(watch,true);
        EnchantersFieldItem.setEnabled(field,false);
        dev.arsmisc.item.RealityMarbleItem.setEnabled(marble,false);
        inventory.setEquippedCurio("charm",0,watch);
        inventory.setEquippedCurio("charm",1,field);
        inventory.setEquippedCurio("charm",2,marble);
        h.assertTrue(ToggleCastingPayload.toggle(player),"Shared toggle found no equipped accessories");
        h.assertTrue(!EnchantersPocketWatchItem.enabled(watch) && !EnchantersFieldItem.enabled(field)
                && !dev.arsmisc.item.RealityMarbleItem.enabled(marble),"Mixed states did not all switch off");
        h.assertTrue(ToggleCastingPayload.toggle(player),"Shared toggle could not turn accessories on");
        h.assertTrue(EnchantersPocketWatchItem.enabled(watch) && EnchantersFieldItem.enabled(field)
                && dev.arsmisc.item.RealityMarbleItem.enabled(marble),"Not all accessories switched on");
        inventory.setSlotActive("charm",2,false);
        ToggleCastingPayload.toggle(player);
        h.assertTrue(!EnchantersPocketWatchItem.enabled(watch) && !EnchantersFieldItem.enabled(field)
                && dev.arsmisc.item.RealityMarbleItem.enabled(marble),"Inactive slot was toggled");
        handler.getStacks().setStackInSlot(0,ItemStack.EMPTY);
        handler.getStacks().setStackInSlot(1,ItemStack.EMPTY);
        h.assertTrue(!ToggleCastingPayload.toggle(player),"Inactive-only equipment was toggled");
        h.succeed();
    }
}
