package dev.arsmisc;

import dev.arsmisc.entity.SummonedGuardian;
import dev.arsmisc.registry.ModEntities;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.method.MethodSelf;
import com.hollingsworth.arsnouveau.common.spell.augment.AugmentExtendTime;
import com.hollingsworth.arsnouveau.setup.registry.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.effect.*;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.*;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder("ars_misc") @PrefixGameTestTemplate(false)
public final class GuardianGameTests {
    private static SummonedGuardian guardian(GameTestHelper h,net.minecraft.world.entity.LivingEntity owner) {
        var g=ModEntities.SUMMONED_GUARDIAN.get().create(h.getLevel());g.bindOwner(owner);g.setPos(owner.position().add(1,0,0));h.getLevel().addFreshEntity(g);return g;
    }
    @GameTest(template="empty",templateNamespace="ars_misc")
    public static void nativeDeathEventRetaliatesOnceAndIgnoresRetirement(GameTestHelper h) {
        var owner=h.makeMockPlayer(GameType.SURVIVAL);owner.setPos(h.absoluteVec(new Vec3(2,2,2)));
        top.theillusivec4.curios.api.CuriosApi.getCuriosInventory(owner).orElseThrow()
            .setEquippedCurio("an_focus",0,ItemsRegistry.SUMMONING_FOCUS.get().getDefaultInstance());
        var g=guardian(h,owner);var attacker=h.spawnWithNoFreeWill(EntityType.COW,3,2,3);
        var count=new java.util.concurrent.atomic.AtomicInteger();
        java.util.function.Consumer<com.hollingsworth.arsnouveau.api.event.SummonEvent.Death> listener=e->{
            if(e.summon==g) { h.assertTrue(!e.wasExpiration,"Combat death marked expiration");count.incrementAndGet(); }
        };
        net.neoforged.neoforge.common.NeoForge.EVENT_BUS.addListener(net.neoforged.bus.api.EventPriority.NORMAL,false,com.hollingsworth.arsnouveau.api.event.SummonEvent.Death.class,listener);
        try {
            float before=attacker.getHealth();var source=h.getLevel().damageSources().mobAttack(attacker);
            h.assertTrue(g.hurt(source,100),"Lethal hit failed");
            h.assertTrue(count.get()==1 && attacker.getHealth()==before-5,"Native death or core retaliation failed: events="+count.get()+", health="+attacker.getHealth());
            g.die(source);h.assertTrue(count.get()==1,"Death event repeated");
        } finally { net.neoforged.neoforge.common.NeoForge.EVENT_BUS.unregister(listener); }
        var retired=guardian(h,owner);float health=attacker.getHealth();retired.setTicksLeft(1);retired.tick();
        var dispelled=guardian(h,owner);dispelled.onDispel(owner);
        h.assertTrue(attacker.getHealth()==health,"Retirement caused retaliation");h.succeed();
    }
    @GameTest(template="empty",templateNamespace="ars_misc",timeoutTicks=140)
    public static void patrolKeepsDistanceFromOwner(GameTestHelper h) {
        for(int x=0;x<11;x++)for(int z=0;z<11;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));
        var g=guardian(h,p);g.updatePatrol(p);
        h.runAfterDelay(100,()->{
            double dx=g.getX()-p.getX(),dz=g.getZ()-p.getZ();double horizontal=Math.sqrt(dx*dx+dz*dz);
            h.assertTrue(horizontal>=3.0 && horizontal<=4.8,"Patrol distance not near four blocks: "+horizontal);h.succeed();
        });
    }
    @GameTest(template="empty",templateNamespace="ars_misc")
    public static void summonHasNativeOwnerLifetimeSicknessAndMana(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));
        var spell=new Spell(MethodSelf.INSTANCE,EffectSummonGuardian.INSTANCE);var ctx=SpellContext.fromEntity(spell,p,ItemStack.EMPTY);
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(2000);mana.setMana(1000);double before=mana.getCurrentMana();
        var resolver=new SpellResolver(ctx).withSilent(true);h.assertTrue(resolver.onCast(ItemStack.EMPTY,h.getLevel()),"Native summon cast failed");
        var entities=h.getLevel().getEntitiesOfClass(SummonedGuardian.class,p.getBoundingBox().inflate(4));
        h.assertTrue(entities.size()==1,"Expected one guardian");var g=entities.getFirst();
        h.assertTrue(g.getTicksLeft()==1200 && p.getUUID().equals(g.getOwnerUUID()),"Wrong owner or lifetime");
        h.assertTrue(p.hasEffect(ModPotions.SUMMONING_SICKNESS_EFFECT) && p.getEffect(ModPotions.SUMMONING_SICKNESS_EFFECT).getDuration()==1200,"Wrong native sickness");
        h.assertTrue(mana.getCurrentMana()<before && EffectSummonGuardian.INSTANCE.getDefaultManaCost()==300,"Wrong summon mana");
        EffectSummonGuardian.INSTANCE.onResolve(new EntityHitResult(p),h.getLevel(),p,new SpellStats.Builder().build(),ctx,resolver);
        h.assertTrue(h.getLevel().getEntitiesOfClass(SummonedGuardian.class,p.getBoundingBox().inflate(4)).size()==1,"Ignored native summoning sickness");
        h.succeed();
    }
    @GameTest(template="empty",templateNamespace="ars_misc")
    public static void supportPrioritiesAndNoSelfHealing(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));var g=guardian(h,p);
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(1000);mana.setMana(500);double before=mana.getCurrentMana();
        g.setHealth(3);p.setHealth(3);g.assistOnce();h.assertTrue(p.getHealth()>3,"Low health owner not healed");
        h.assertTrue(g.getHealth()==3 && !g.hasEffect(MobEffects.REGENERATION),"Guardian healed itself");
        p.setHealth(p.getMaxHealth());p.igniteForSeconds(10);g.assistOnce();h.assertTrue(!p.isOnFire(),"Owner not extinguished");
        g.assistOnce();var regen=p.getEffect(MobEffects.REGENERATION);
        h.assertTrue(regen!=null && regen.getAmplifier()==0 && regen.getDuration()==300,"Wrong regeneration strength/duration");
        h.assertTrue(mana.getCurrentMana()==before,"Support spent owner mana");
        var wolf=h.spawnWithNoFreeWill(EntityType.WOLF,2,2,3);wolf.setOwnerUUID(p.getUUID());
        var other=h.spawnWithNoFreeWill(EntityType.COW,3,2,3);
        h.assertTrue(g.isBeneficiary(wolf) && !g.isBeneficiary(other) && !g.isBeneficiary(g),"Wrong support ownership");
        h.succeed();
    }
    @GameTest(template="empty",templateNamespace="ars_misc",timeoutTicks=100)
    public static void escapeUsesInvisibilityThenMilkWithoutDiscard(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));var g=guardian(h,p);
        g.addEffect(new MobEffectInstance(MobEffects.POISON,400));
        h.assertTrue(g.hurt(h.getLevel().damageSources().generic(),1) && g.hasEffect(MobEffects.INVISIBILITY),"Surviving damage did not trigger invisibility");
        h.runAfterDelay(65,()->{
            h.assertTrue(g.isAlive() && !g.isRemoved(),"Milk discarded guardian");
            h.assertTrue(!g.hasEffect(MobEffects.INVISIBILITY) && !g.hasEffect(MobEffects.POISON),"Milk did not clear eligible effects");
            g.invulnerableTime=0;g.hurt(h.getLevel().damageSources().generic(),1);
            h.assertTrue(!g.hasEffect(MobEffects.INVISIBILITY),"Escape cooldown ignored");h.succeed();
        });
    }
    @GameTest(template="empty",templateNamespace="ars_misc")
    public static void lifetimePersistenceAndExpiration(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));var g=guardian(h,p);g.setTicksLeft(1);
        var tag=new net.minecraft.nbt.CompoundTag();g.addAdditionalSaveData(tag);
        var copy=ModEntities.SUMMONED_GUARDIAN.get().create(h.getLevel());copy.readAdditionalSaveData(tag);
        h.assertTrue(copy.getTicksLeft()==1 && p.getUUID().equals(copy.getOwnerUUID()),"Lost summon lifetime/owner in save");
        g.tick();h.assertTrue(g.isRemoved(),"Guardian survived expiration");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=80)
    public static void supportSpellUsesNativeEvokerPoseAndEnds(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var g=guardian(h,p);
        g.assistOnce();
        h.assertTrue(p.hasEffect(MobEffects.REGENERATION),"Support spell did not resolve");
        h.assertTrue(g.isCastingSpell() && g.getArmPose()==net.minecraft.world.entity.monster.AbstractIllager.IllagerArmPose.SPELLCASTING,"Native evoker casting pose was not started");
        h.runAfterDelay(25,()->{
            h.assertTrue(!g.isCastingSpell() && g.getArmPose()==net.minecraft.world.entity.monster.AbstractIllager.IllagerArmPose.CROSSED,"Casting pose did not return to idle");h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void noSupportNeededDoesNotPlayCastingPose(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));
        p.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.REGENERATION,600));var g=guardian(h,p);
        g.assistOnce();h.assertTrue(!g.isCastingSpell(),"Idle guardian played casting pose without casting");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void enemyBuffDispelPreservesDebuffsAndAllies(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var g=guardian(h,p);
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,600));
        var enemy=h.spawnWithNoFreeWill(EntityType.ZOMBIE,7,2,5);enemy.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,600));enemy.addEffect(new MobEffectInstance(MobEffects.WITHER,600));
        h.assertTrue(g.canDispelEnemy(enemy),"Buffed hostile entity was not eligible");g.assistOnce();
        h.assertTrue(!enemy.hasEffect(MobEffects.DAMAGE_BOOST) && enemy.hasEffect(MobEffects.WITHER),"Enemy dispel removed debuff or left removable buff");
        h.assertTrue(p.hasEffect(MobEffects.DAMAGE_BOOST),"Guardian removed owner's buff");
        var ally=h.spawnWithNoFreeWill(EntityType.WOLF,6,2,6);ally.setOwnerUUID(p.getUUID());ally.addEffect(new MobEffectInstance(MobEffects.REGENERATION,600));
        h.assertTrue(!g.canDispelEnemy(ally),"Owned pet was eligible for enemy dispel");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void hostileSummonDispelKeepsFriendlySummon(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var g=guardian(h,p);
        var foreign=h.spawnWithNoFreeWill(EntityType.COW,25,2,5);
        var enemy=com.hollingsworth.arsnouveau.setup.registry.ModEntities.SUMMON_WOLF.get().create(h.getLevel());enemy.setNoAi(true);enemy.setTicksLeft(1200);enemy.setOwnerID(foreign.getUUID());enemy.setPos(h.absoluteVec(new Vec3(7,2,5)));enemy.setTarget(p);h.getLevel().addFreshEntity(enemy);
        var own=com.hollingsworth.arsnouveau.setup.registry.ModEntities.SUMMON_WOLF.get().create(h.getLevel());own.setNoAi(true);own.setTicksLeft(1200);own.setOwnerID(p.getUUID());own.setPos(h.absoluteVec(new Vec3(6,2,6)));h.getLevel().addFreshEntity(own);
        h.assertTrue(g.canDispelEnemy(enemy) && !g.canDispelEnemy(own),"Wrong summon dispel ownership");g.assistOnce();
        h.assertTrue(enemy.getTicksLeft()==0 && own.getTicksLeft()>0,"Native summon dispel did not preserve ally");enemy.tick();
        h.assertTrue(enemy.isRemoved() && !own.isRemoved(),"Dispelled enemy summon did not expire");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void urgentHealingPrecedesDispel(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));p.setHealth(4);var g=guardian(h,p);
        var enemy=h.spawnWithNoFreeWill(EntityType.ZOMBIE,7,2,5);enemy.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,600));g.assistOnce();
        h.assertTrue(p.getHealth()>4 && enemy.hasEffect(MobEffects.DAMAGE_BOOST),"Dispel overrode urgent healing");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void playerSpellDamageMarksNeutralBuffedEnemy(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var g=guardian(h,p);
        var enemy=h.spawnWithNoFreeWill(EntityType.COW,7,2,5);enemy.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST,600));
        h.assertTrue(!g.canDispelEnemy(enemy),"Peaceful buffed entity was considered hostile");enemy.hurt(h.getLevel().damageSources().indirectMagic(p,p),1);
        h.assertTrue(g.canDispelEnemy(enemy),"Player spell damage did not mark enemy");g.assistOnce();
        h.assertTrue(!enemy.hasEffect(MobEffects.DAMAGE_BOOST),"Marked enemy buff was not dispelled");h.succeed();
    }
}
