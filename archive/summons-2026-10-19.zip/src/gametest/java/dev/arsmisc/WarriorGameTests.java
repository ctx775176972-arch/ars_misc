package dev.arsmisc;

import dev.arsmisc.entity.SummonedWarrior;
import dev.arsmisc.registry.ModEntities;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.method.MethodSelf;
import com.hollingsworth.arsnouveau.common.spell.augment.AugmentAmplify;
import com.hollingsworth.arsnouveau.setup.registry.*;
import net.minecraft.gametest.framework.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.*;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.*;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder("ars_misc") @PrefixGameTestTemplate(false)
public final class WarriorGameTests {
    private static SummonedWarrior warrior(GameTestHelper h,net.minecraft.world.entity.LivingEntity owner) {
        var w=ModEntities.SUMMONED_WARRIOR.get().create(h.getLevel());w.bindOwner(owner);w.setPos(owner.position().add(1,0,0));h.getLevel().addFreshEntity(w);return w;
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void armorSnapshotEquipmentAndSave(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));
        p.getAttribute(Attributes.ARMOR).setBaseValue(18);p.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(8);
        var w=warrior(h,p);h.assertTrue(w.getMainHandItem().is(Items.DIAMOND_AXE) && w.getOffhandItem().isEmpty(),"Wrong default equipment");
        p.getAttribute(Attributes.ARMOR).setBaseValue(0);p.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(0);
        h.assertTrue(w.getAttributeValue(Attributes.ARMOR)==18 && w.getAttributeValue(Attributes.ARMOR_TOUGHNESS)==8,"Armor snapshot changed after owner changed gear");
        w.configureWeapon();h.assertTrue(w.getMainHandItem().is(Items.DIAMOND_AXE),"Default diamond equipment failed");
        var tag=new net.minecraft.nbt.CompoundTag();w.addAdditionalSaveData(tag);var restored=ModEntities.SUMMONED_WARRIOR.get().create(h.getLevel());restored.readAdditionalSaveData(tag);
        h.assertTrue(restored.getAttributeValue(Attributes.ARMOR)==18 && restored.getAttributeValue(Attributes.ARMOR_TOUGHNESS)==8 && restored.getMainHandItem().is(Items.DIAMOND_AXE),"Snapshot/equipment lost on reload");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void nativeSummonGetsFocusAndDeathRetaliation(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));
        top.theillusivec4.curios.api.CuriosApi.getCuriosInventory(p).orElseThrow().setEquippedCurio("an_focus",0,ItemsRegistry.SUMMONING_FOCUS.get().getDefaultInstance());
        var mana=CapabilityRegistry.getMana(p);mana.setMaxMana(2000);mana.setMana(1000);
        h.assertTrue(!EffectSummonWarrior.INSTANCE.getCompatibleAugments().contains(AugmentAmplify.INSTANCE),"Warrior still accepts Amplify");
        var spell=new Spell(MethodSelf.INSTANCE,EffectSummonWarrior.INSTANCE);
        var resolver=new SpellResolver(SpellContext.fromEntity(spell,p,ItemStack.EMPTY)).withSilent(true);h.assertTrue(resolver.onCast(ItemStack.EMPTY,h.getLevel()),"Native cast failed");
        var summons=h.getLevel().getEntitiesOfClass(SummonedWarrior.class,p.getBoundingBox().inflate(4));h.assertTrue(summons.size()==1,"Wrong summon count");var w=summons.getFirst();
        h.assertTrue(w.getMainHandItem().is(Items.DIAMOND_AXE) && w.getTicksLeft()==2400,"Default diamond axe/focus duration failed");
        h.assertTrue(w.hasEffect(MobEffects.DAMAGE_BOOST) && w.getEffect(MobEffects.DAMAGE_BOOST).getAmplifier()==2 && w.hasEffect(MobEffects.MOVEMENT_SPEED),"Focus buffs missing");
        h.assertTrue(p.hasEffect(ModPotions.SUMMONING_SICKNESS_EFFECT) && p.getEffect(ModPotions.SUMMONING_SICKNESS_EFFECT).getDuration()==1200,"Wrong native sickness");
        var cow=h.spawnWithNoFreeWill(EntityType.COW,3,2,3);float health=cow.getHealth();w.hurt(h.getLevel().damageSources().mobAttack(cow),100);
        h.assertTrue(cow.getHealth()==health-5,"Native death retaliation missing");w.die(h.getLevel().damageSources().mobAttack(cow));h.assertTrue(cow.getHealth()==health-5,"Death retaliation repeated");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void axeUsesNativePlayerShieldDisable(GameTestHelper h) {
        var owner=h.makeMockPlayer(GameType.SURVIVAL);owner.setPos(h.absoluteVec(new Vec3(4,2,4)));var w=warrior(h,owner);
        var defender=h.makeMockPlayer(GameType.SURVIVAL);defender.setPos(h.absoluteVec(new Vec3(2,2,2)));defender.setYRot(0);w.setPos(h.absoluteVec(new Vec3(2,2,3)));
        defender.setItemInHand(InteractionHand.OFF_HAND,new ItemStack(Items.SHIELD));defender.startUsingItem(InteractionHand.OFF_HAND);
        for(int tick=0;tick<6;tick++)defender.tick();
        h.assertTrue(defender.isBlocking(),"Shield test did not start blocking");
        w.doHurtTarget(defender);
        h.assertTrue(defender.getCooldowns().isOnCooldown(Items.SHIELD),"Native axe did not disable shield");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void targetsEnemiesButNotOwnedCompanions(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(2,2,2)));var w=warrior(h,p);
        var g=ModEntities.SUMMONED_GUARDIAN.get().create(h.getLevel());g.bindOwner(p);g.setPos(p.position());h.getLevel().addFreshEntity(g);
        var wolf=h.spawnWithNoFreeWill(EntityType.WOLF,2,2,3);wolf.setOwnerUUID(p.getUUID());var zombie=h.spawnWithNoFreeWill(EntityType.ZOMBIE,3,2,3);var illager=h.spawnWithNoFreeWill(EntityType.VINDICATOR,3,2,2);
        h.assertTrue(!w.validEnemy(p) && !w.validEnemy(g) && !w.validEnemy(wolf) && w.validEnemy(illager),"Wrong allegiance rules");
        w.updateCombatTarget();h.assertTrue(w.getTarget()==zombie || w.getTarget()==illager,"No hostile target selected");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=140)
    public static void idlePatrolAndExpiration(GameTestHelper h) {
        for(int x=0;x<11;x++)for(int z=0;z<11;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));var w=warrior(h,p);w.updatePatrol(p);
        h.runAfterDelay(100,()->{
            double dx=w.getX()-p.getX(),dz=w.getZ()-p.getZ();double radius=Math.sqrt(dx*dx+dz*dz);
            h.assertTrue(radius>=3.0 && radius<=4.8 && w.getTarget()==null,"Idle patrol failed: "+radius);
            w.setTicksLeft(1);w.tick();h.assertTrue(w.isRemoved(),"Warrior did not expire");h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void ownerThreatPreemptsCurrentAndSpellTarget(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(3,2,3)));var w=warrior(h,p);
        var old=h.spawnWithNoFreeWill(EntityType.ZOMBIE,4,2,3);
        var attacked=h.spawnWithNoFreeWill(EntityType.COW,3,2,4);
        var attacker=h.spawnWithNoFreeWill(EntityType.ZOMBIE,4,2,4);
        w.setTarget(old);attacked.hurt(h.getLevel().damageSources().indirectMagic(p,p),1);
        w.updateCombatTarget();h.assertTrue(w.getTarget()==attacked,"Owner spell target did not preempt current enemy");
        p.hurt(h.getLevel().damageSources().mobAttack(attacker),1);
        w.updateCombatTarget();h.assertTrue(w.getTarget()==attacker,"Owner attacker did not have highest priority");
        attacker.kill();w.updateCombatTarget();h.assertTrue(w.getTarget()==attacked,"Dead priority target prevented fallback to owner damage target");
        attacked.kill();w.updateCombatTarget();h.assertTrue(w.getTarget()==old,"Dead targets prevented selecting another enemy");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=200)
    public static void resumesPatrolAfterActualKill(GameTestHelper h) {
        for(int x=0;x<11;x++)for(int z=0;z<11;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));var w=warrior(h,p);
        var cow=h.spawnWithNoFreeWill(EntityType.COW,7,2,5);cow.setHealth(1);w.recordOwnerDamage(cow);w.updateCombatTarget();
        h.runAfterDelay(60,()->{
            h.assertTrue(!cow.isAlive(),"Warrior failed to kill melee target");
            h.assertTrue(w.getTarget()==null,"Warrior retained a target after kill: "+(w.getTarget()==null?"none":w.getTarget().getType()));
            // Moving the owner requires a fresh patrol path after the melee goal has stopped.
            p.setPos(h.absoluteVec(new Vec3(3.5,2,5.5)));
        });
        h.runAfterDelay(160,()->{
            double dx=w.getX()-p.getX(),dz=w.getZ()-p.getZ();double radius=Math.sqrt(dx*dx+dz*dz);
            h.assertTrue(w.getTarget()==null && radius>=3.0 && radius<=4.8,"Warrior did not resume owner patrol after kill: "+radius);h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void selfDefensePreemptsOrdinaryTargetButProtectsOwnerFirst(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var w=warrior(h,p);
        var ordinary=h.spawnWithNoFreeWill(EntityType.ZOMBIE,7,2,5);
        var attacker=h.spawnWithNoFreeWill(EntityType.COW,6,2,6);
        var ownerTarget=h.spawnWithNoFreeWill(EntityType.COW,5,2,6);
        var ownerAttacker=h.spawnWithNoFreeWill(EntityType.ZOMBIE,5,2,7);
        w.setTarget(ordinary);h.assertTrue(w.hurt(h.getLevel().damageSources().mobAttack(attacker),1),"Test attack was rejected");
        h.assertTrue(w.getTarget()==attacker,"Self-defense did not immediately replace ordinary target");
        ownerTarget.hurt(h.getLevel().damageSources().indirectMagic(p,p),1);w.updateCombatTarget();
        h.assertTrue(w.getTarget()==ownerTarget,"Self-defense overrode owner's damage target");
        p.hurt(h.getLevel().damageSources().mobAttack(ownerAttacker),1);w.updateCombatTarget();
        h.assertTrue(w.getTarget()==ownerAttacker,"Self-defense overrode owner's attacker");
        ownerAttacker.kill();ownerTarget.kill();w.updateCombatTarget();
        h.assertTrue(w.getTarget()==attacker,"Self-defense did not resume after owner threats died");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=120)
    public static void actuallyRetaliatesAfterTakingDamage(GameTestHelper h) {
        for(int x=0;x<11;x++)for(int z=0;z<11;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));var w=warrior(h,p);
        var attacker=h.spawnWithNoFreeWill(EntityType.COW,7,2,5);attacker.setHealth(1);
        h.assertTrue(w.hurt(h.getLevel().damageSources().mobAttack(attacker),1),"Test attack was rejected");
        h.runAfterDelay(60,()->{
            h.assertTrue(!attacker.isAlive(),"Warrior selected attacker but did not retaliate in melee");
            h.assertTrue(w.getTarget()==null,"Warrior retained killed attacker");h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void repeatedHitsDoNotMakeRetaliationTargetOscillate(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var w=warrior(h,p);
        var first=h.spawnWithNoFreeWill(EntityType.ZOMBIE,6,2,6);var second=h.spawnWithNoFreeWill(EntityType.ZOMBIE,7,2,6);
        w.hurt(h.getLevel().damageSources().mobAttack(first),1);h.assertTrue(w.getTarget()==first,"First attacker was not selected");
        w.invulnerableTime=0;w.hurt(h.getLevel().damageSources().mobAttack(second),1);
        h.assertTrue(w.getTarget()==first,"Crowd hits made the retaliation target oscillate");
        first.kill();w.updateCombatTarget();h.assertTrue(w.getTarget()==second,"Did not choose surviving attacker after first died");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=100)
    public static void attacksNearbyBlockerWithoutLosingOwnerPriority(GameTestHelper h) {
        for(int x=0;x<16;x++)for(int z=0;z<16;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));var w=warrior(h,p);
        // Enclose the warrior and a close enemy while the owner's attacker remains outside.
        for(int y=2;y<5;y++)for(int x=5;x<=8;x++)for(int z=4;z<=7;z++)
            if(x==5 || x==8 || z==4 || z==7)h.setBlock(new net.minecraft.core.BlockPos(x,y,z),net.minecraft.world.level.block.Blocks.STONE);
        w.setPos(h.absoluteVec(new Vec3(6.5,2,5.5)));
        var blocker=h.spawnWithNoFreeWill(EntityType.ZOMBIE,7,2,5);blocker.setPos(h.absoluteVec(new Vec3(7.2,2,5.5)));
        blocker.getAttribute(Attributes.MAX_HEALTH).setBaseValue(1000);blocker.setHealth(1000);
        var preferred=h.spawnWithNoFreeWill(EntityType.ZOMBIE,12,2,5);p.setLastHurtByMob(preferred);w.updateCombatTarget();
        h.runAfterDelay(60,()->{
            h.assertTrue(blocker.getHealth()<1000,"Warrior refused to attack close enemy blocking its priority target");
            h.assertTrue(w.getTarget()==preferred,"Close attacks replaced owner priority target");h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=220)
    public static void fightsWhileSurroundedByZombies(GameTestHelper h) {
        for(int x=0;x<16;x++)for(int z=0;z<16;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(7.5,2,7.5)));var w=warrior(h,p);
        w.setPos(h.absoluteVec(new Vec3(8.5,2,8.5)));w.getAttribute(Attributes.MAX_HEALTH).setBaseValue(500);w.setHealth(500);
        var enemies=new java.util.ArrayList<net.minecraft.world.entity.monster.Zombie>();
        for(int i=0;i<8;i++) {
            double angle=i*Math.PI/4;var zombie=h.spawn(EntityType.ZOMBIE,8,2,8);
            zombie.setPos(h.absoluteVec(new Vec3(8.5+1.5*Math.cos(angle),2,8.5+1.5*Math.sin(angle))));
            zombie.setItemSlot(EquipmentSlot.HEAD,new ItemStack(Items.IRON_HELMET));zombie.setTarget(w);enemies.add(zombie);
        }
        h.runAfterDelay(160,()->{
            long damaged=enemies.stream().filter(e->!e.isAlive() || e.getHealth()<e.getMaxHealth()).count();
            h.assertTrue(w.getHealth()<500,"Surrounding zombies did not attack the warrior");
            h.assertTrue(damaged>=2,"Warrior did not fight back against a crowd: "+damaged);h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=100)
    public static void recallsBothSummonsEvenWithCombatTarget(GameTestHelper h) {
        for(int x=0;x<12;x++)for(int z=0;z<12;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));var w=warrior(h,p);
        var enemy=h.spawnWithNoFreeWill(EntityType.ZOMBIE,8,2,5);w.recordOwnerDamage(enemy);w.setPos(h.absoluteVec(new Vec3(25,2,5)));
        var g=ModEntities.SUMMONED_GUARDIAN.get().create(h.getLevel());g.bindOwner(p);g.setPos(h.absoluteVec(new Vec3(25,2,6)));h.getLevel().addFreshEntity(g);
        h.runAfterDelay(15,()->{
            h.assertTrue(w.distanceToSqr(p)<36 && g.distanceToSqr(p)<36,"Combat target prevented summon recall");
            h.assertTrue(w.getTarget()==enemy,"Recall lost valid owner combat target");
            h.assertTrue(h.getLevel().noCollision(w,w.getBoundingBox()) && h.getLevel().noCollision(g,g.getBoundingBox()),"Recall placed summon in solid blocks");h.succeed();
        });
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=100)
    public static void noSafeRecallPointDoesNotTeleportIntoVoid(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,15,5.5)));var w=warrior(h,p);
        w.setNoGravity(true);w.setPos(h.absoluteVec(new Vec3(25,15,5)));w.getNavigation().stop();
        h.runAfterDelay(15,()->{h.assertTrue(w.distanceToSqr(p)>144,"Summon teleported without a safe floor");h.succeed();});
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc",timeoutTicks=160)
    public static void newOwnerDamageRestartsChaseAfterPathFailure(GameTestHelper h) {
        for(int x=0;x<16;x++)for(int z=0;z<16;z++)h.setBlock(new net.minecraft.core.BlockPos(x,1,z),net.minecraft.world.level.block.Blocks.STONE);
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5.5,2,5.5)));var w=warrior(h,p);
        var unreachable=h.spawnWithNoFreeWill(EntityType.COW,9,7,5);unreachable.setNoGravity(true);w.recordOwnerDamage(unreachable);
        var newTarget=h.spawnWithNoFreeWill(EntityType.COW,10,2,5);newTarget.setHealth(1);
        h.runAfterDelay(30,()->{
            h.assertTrue(unreachable.isAlive() && unreachable.getY()>w.getY()+3,"Unreachable target did not remain above the warrior");
            newTarget.hurt(h.getLevel().damageSources().indirectMagic(p,p),0.1f);
            h.assertTrue(w.getTarget()==newTarget,"Owner damage did not immediately replace unreachable target");
        });
        h.runAfterDelay(110,()->{h.assertTrue(!newTarget.isAlive(),"Warrior failed to restart chase after an unreachable target");h.succeed();});
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void enemyArsSummonMustHaveForeignOwnerAndAttackCaster(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var w=warrior(h,p);
        var foreign=h.spawnWithNoFreeWill(EntityType.COW,25,2,5);
        var wolf=com.hollingsworth.arsnouveau.setup.registry.ModEntities.SUMMON_WOLF.get().create(h.getLevel());
        wolf.setNoAi(true);wolf.setPos(h.absoluteVec(new Vec3(7,2,5)));wolf.setOwnerID(foreign.getUUID());h.getLevel().addFreshEntity(wolf);
        h.assertTrue(!w.automaticEnemy(wolf),"Peaceful foreign summon was considered hostile");
        wolf.setTarget(p);w.updateCombatTarget();h.assertTrue(w.getTarget()==wolf,"Enemy Ars wolf attacking caster was not selected");
        wolf.setOwnerID(p.getUUID());w.setTarget(null);w.updateCombatTarget();
        h.assertTrue(!w.validEnemy(wolf) && w.getTarget()==null,"Own summon became an enemy");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void ironSummonerOwnershipAndHostility(GameTestHelper h) throws Exception {
        if(!net.neoforged.fml.ModList.get().isLoaded("irons_spellbooks")) { h.succeed();return; }
        var p=h.spawnWithNoFreeWill(EntityType.COW,5,2,5);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var w=warrior(h,p);
        var foreign=h.spawnWithNoFreeWill(EntityType.COW,25,2,5);
        var registry=Class.forName("io.redspace.ironsspellbooks.registries.EntityRegistry");
        for(String field:new String[]{"SUMMONED_ZOMBIE","SUMMONED_SKELETON","SUMMONED_VEX"}) {
            var holder=(net.neoforged.neoforge.registries.DeferredHolder<?,?>)registry.getField(field).get(null);
            var summon=(Mob)((EntityType<?>)holder.get()).create(h.getLevel());summon.setNoAi(true);
            summon.setPos(h.absoluteVec(new Vec3(7,2,5)));h.getLevel().addFreshEntity(summon);
            var setter=summon.getClass().getMethod("setSummoner",LivingEntity.class);setter.invoke(summon,foreign);
            h.assertTrue(dev.arsmisc.entity.SummonOwnership.ownerId(summon).equals(foreign.getUUID()),"Iron summoner was not resolved: "+field);
            h.assertTrue(!w.automaticEnemy(summon),"Peaceful foreign Iron summon was considered hostile: "+field);
            w.setTarget(summon);h.assertTrue(w.getTarget()==null,"Iron peaceful summon protection was bypassed: "+field);
            summon.setTarget(p);w.setTarget(null);w.updateCombatTarget();
            h.assertTrue(w.automaticEnemy(summon),"Hostile Iron summon ownership was not recognized: "+field);
            h.assertTrue(w.getTarget()==null,"Iron native target restriction was bypassed: "+field);
            float before=summon.getHealth();w.doHurtTarget(summon);
            h.assertTrue(summon.getHealth()<before,"Warrior could not damage hostile Iron summon: "+field);
            var invisible=net.minecraft.core.registries.BuiltInRegistries.MOB_EFFECT.getHolder(net.minecraft.resources.ResourceLocation.fromNamespaceAndPath("irons_spellbooks","true_invisibility")).orElseThrow();
            summon.addEffect(new net.minecraft.world.effect.MobEffectInstance(invisible,100));w.setTarget(null);w.updateCombatTarget();
            h.assertTrue(w.getTarget()==null,"Iron true invisibility target restriction was bypassed: "+field);summon.removeEffect(invisible);
            setter.invoke(summon,p);w.setTarget(null);w.updateCombatTarget();
            h.assertTrue(!w.validEnemy(summon) && w.getTarget()==null,"Own Iron summon was considered hostile: "+field);summon.discard();
        }
        h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void maxHealthSnapshotAndSave(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));var base=warrior(h,p);
        h.assertTrue(base.getMaxHealth()==24 && base.getHealth()==24,"Default warrior health floor changed");
        p.getAttribute(Attributes.MAX_HEALTH).setBaseValue(60);p.setHealth(10);var w=warrior(h,p);
        h.assertTrue(w.getMaxHealth()==60 && w.getHealth()==60,"Warrior inherited current health instead of maximum health");
        p.getAttribute(Attributes.MAX_HEALTH).setBaseValue(20);
        h.assertTrue(w.getMaxHealth()==60,"Health snapshot changed after owner changed attributes");
        var tag=new net.minecraft.nbt.CompoundTag();w.addAdditionalSaveData(tag);var restored=ModEntities.SUMMONED_WARRIOR.get().create(h.getLevel());restored.readAdditionalSaveData(tag);
        h.assertTrue(restored.getMaxHealth()==60 && restored.getHealth()==60,"Health snapshot was not saved");h.succeed();
    }
    @GameTest(template="warrior_ai",templateNamespace="ars_misc")
    public static void witchStyleResistanceHalvesTaggedDamageOnly(GameTestHelper h) {
        var p=h.makeMockPlayer(GameType.SURVIVAL);p.setPos(h.absoluteVec(new Vec3(5,2,5)));
        var attacker=h.spawnWithNoFreeWill(EntityType.COW,7,2,5);
        for(var type:new net.minecraft.resources.ResourceKey[]{net.minecraft.world.damagesource.DamageTypes.MAGIC,net.minecraft.world.damagesource.DamageTypes.INDIRECT_MAGIC,net.minecraft.world.damagesource.DamageTypes.SONIC_BOOM,net.minecraft.world.damagesource.DamageTypes.THORNS}) {
            var w=warrior(h,p);w.getAttribute(Attributes.ARMOR).setBaseValue(0);
            var holder=h.getLevel().registryAccess().registryOrThrow(net.minecraft.core.registries.Registries.DAMAGE_TYPE).getHolderOrThrow(type);
            w.hurt(new net.minecraft.world.damagesource.DamageSource(holder,attacker),8);
            h.assertTrue(Math.abs(w.getHealth()-20)<0.001,"Tagged damage was not reduced by 50%: "+type);w.discard();
        }
        var ordinary=warrior(h,p);ordinary.hurt(h.getLevel().damageSources().mobAttack(attacker),8);
        h.assertTrue(Math.abs(ordinary.getHealth()-16)<0.001,"Physical damage was incorrectly reduced");
        var self=warrior(h,p);self.hurt(h.getLevel().damageSources().indirectMagic(self,self),8);
        h.assertTrue(Math.abs(self.getHealth()-20)<0.001,"Warrior incorrectly received witch self-damage immunity");
        var stacked=warrior(h,p);stacked.addEffect(new net.minecraft.world.effect.MobEffectInstance(MobEffects.DAMAGE_RESISTANCE,100,0));
        stacked.hurt(h.getLevel().damageSources().magic(),10);
        h.assertTrue(Math.abs(stacked.getHealth()-20)<0.001,"Native Resistance and innate resistance did not multiply");h.succeed();
    }
}
