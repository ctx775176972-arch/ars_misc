package dev.arsmisc;

import net.neoforged.bus.api.EventPriority;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.BuildCreativeModeTabContentsEvent;

/** Ars Nouveau's glyph tab enumerates the whole registry without visibility filtering. */
@EventBusSubscriber(modid = ArsMiscMod.MOD_ID, bus = EventBusSubscriber.Bus.MOD)
public final class HiddenSummonGlyphs {
    private HiddenSummonGlyphs() {}

    @SubscribeEvent(priority = EventPriority.LOWEST)
    public static void hideFromCreativeTabs(BuildCreativeModeTabContentsEvent event) {
        for (var glyph : java.util.List.of(EffectSummonGuardian.INSTANCE.getGlyph(), EffectSummonWarrior.INSTANCE.getGlyph())) {
            event.remove(glyph.getDefaultInstance(), net.minecraft.world.item.CreativeModeTab.TabVisibility.PARENT_AND_SEARCH_TABS);
        }
    }
}
