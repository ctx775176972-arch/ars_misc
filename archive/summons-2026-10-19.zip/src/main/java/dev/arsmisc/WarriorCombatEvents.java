package dev.arsmisc;

import dev.arsmisc.entity.SummonedWarrior;
import net.minecraft.world.entity.LivingEntity;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;

/** Records successful owner damage for combat and support summons. */
@EventBusSubscriber(modid=ArsMiscMod.MOD_ID)
public final class WarriorCombatEvents {
    private WarriorCombatEvents() { }
    @SubscribeEvent public static void damaged(LivingDamageEvent.Post event) {
        if(event.getEntity().level().isClientSide || !(event.getSource().getEntity() instanceof LivingEntity owner))return;
        if(event.getNewDamage()<=0 && event.getReduction(DamageContainer.Reduction.ABSORPTION)<=0)return;
        for(var warrior:owner.level().getEntitiesOfClass(SummonedWarrior.class,owner.getBoundingBox().inflate(32),
                w->w.isAlive() && owner.getUUID().equals(w.getOwnerUUID()))) {
            warrior.recordOwnerDamage(event.getEntity());
        }
        for(var guardian:owner.level().getEntitiesOfClass(dev.arsmisc.entity.SummonedGuardian.class,owner.getBoundingBox().inflate(32),
                g->g.isAlive() && owner.getUUID().equals(g.getOwnerUUID())))guardian.recordOwnerDamage(event.getEntity());
    }
}
