package dev.arsmisc.entity;

import com.hollingsworth.arsnouveau.api.entity.*;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.monster.*;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import java.util.*;

/** Pure melee summon; protection is snapshotted at summoning time. */
public final class SummonedWarrior extends Vindicator implements ISummon, IDispellable {
    private UUID ownerId;
    private LivingEntity ownerCache;
    private int ticksLeft=1200;
    private boolean deathEventSent;
    private LivingEntity ownerDamageTarget;
    private LivingEntity retaliationTarget;
    private final OwnerPatrol patrol=new OwnerPatrol(this);
    public SummonedWarrior(EntityType<? extends Vindicator> type,Level level) {
        super(type,level);setPersistenceRequired();setCanJoinRaid(false);configureWeapon();
    }
    public static AttributeSupplier.Builder warriorAttributes() { return Vindicator.createAttributes().add(Attributes.FOLLOW_RANGE,32).add(Attributes.ARMOR).add(Attributes.ARMOR_TOUGHNESS); }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0,new FloatGoal(this));
        goalSelector.addGoal(1,new WarriorMeleeGoal(this));
        goalSelector.addGoal(2,new Goal() {
            { setFlags(EnumSet.of(Goal.Flag.MOVE)); }
            @Override public boolean canUse() { return getTarget()==null && getOwner()!=null; }
            @Override public boolean canContinueToUse() { return canUse(); }
            @Override public void start() { patrol.reset(); }
            @Override public void tick() { var owner=getOwner();if(owner!=null)updatePatrol(owner); }
            @Override public void stop() { getNavigation().stop();patrol.reset(); }
        });
        goalSelector.addGoal(3,new LookAtPlayerGoal(this,Player.class,8));
        goalSelector.addGoal(4,new RandomLookAroundGoal(this));
    }
    public void configureWeapon() {
        setItemSlot(EquipmentSlot.MAINHAND,new ItemStack(Items.DIAMOND_AXE));
        setItemSlot(EquipmentSlot.OFFHAND,ItemStack.EMPTY);setDropChance(EquipmentSlot.MAINHAND,0);
    }
    public void bindOwner(LivingEntity owner) {
        ownerCache=owner;ownerId=owner.getUUID();
        getAttribute(Attributes.MAX_HEALTH).setBaseValue(Math.max(24,owner.getMaxHealth()));
        setHealth(getMaxHealth());
        getAttribute(Attributes.ARMOR).setBaseValue(owner.getAttributeValue(Attributes.ARMOR));
        getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(owner.getAttributeValue(Attributes.ARMOR_TOUGHNESS));
    }
    @Override public UUID getOwnerUUID() { return ownerId; }
    @Override public LivingEntity getOwner() {
        if(ownerCache!=null && ownerCache.isAlive() && ownerCache.level()==level())return ownerCache;
        if(ownerId!=null && level() instanceof ServerLevel server && server.getEntity(ownerId) instanceof LivingEntity living) { ownerCache=living;return living; }
        return null;
    }
    @Override public void setOwnerID(UUID id) { ownerId=id;if(ownerCache!=null && !id.equals(ownerCache.getUUID()))ownerCache=null; }
    @Override public int getTicksLeft() { return ticksLeft; }
    @Override public void setTicksLeft(int ticks) { ticksLeft=Math.max(0,ticks); }
    @Override public boolean onDispel(LivingEntity caster) { discard();return true; }
    @Override public void checkDespawn() { }
    @Override protected int getBaseExperienceReward() { return 0; }
    @Override public boolean isAlliedTo(Entity entity) {
        if(entity==this)return true;var owner=getOwner();
        if(owner!=null && (entity==owner || owner.isAlliedTo(entity)
            || SummonOwnership.isOwnedBy(entity,owner)))return true;
        return getTeam()!=null && entity.getTeam()!=null && getTeam().isAlliedTo(entity.getTeam());
    }
    public boolean validEnemy(LivingEntity target) {
        var owner=getOwner();
        return owner!=null && target!=this && target.isAlive() && !target.isSpectator()
            && !(target instanceof Player) && !isAlliedTo(target) && owner.distanceToSqr(target)<=256;
    }
    public boolean automaticEnemy(LivingEntity target) {
        var owner=getOwner();if(owner==null || !validEnemy(target))return false;
        if(SummonOwnership.isSummon(target))return SummonOwnership.attacksOwner(target,owner);
        return target instanceof Enemy;
    }
    public void recordOwnerDamage(LivingEntity target) { ownerDamageTarget=target;updateCombatTarget(); }
    public void updateCombatTarget() {
        var owner=getOwner();if(owner==null) { setTarget(null);return; }
        if(owner.getLastHurtByMob()!=null && validEnemy(owner.getLastHurtByMob())) { setTarget(owner.getLastHurtByMob());return; }
        if(ownerDamageTarget!=null && validEnemy(ownerDamageTarget)) { setTarget(ownerDamageTarget);return; }
        if(owner.getLastHurtMob()!=null && validEnemy(owner.getLastHurtMob())) { setTarget(owner.getLastHurtMob());return; }
        if(retaliationTarget!=null && validEnemy(retaliationTarget)) { setTarget(retaliationTarget);return; }
        if(getLastHurtByMob()!=null && validEnemy(getLastHurtByMob())) {
            retaliationTarget=getLastHurtByMob();setTarget(retaliationTarget);return;
        }
        if(getTarget()!=null && validEnemy(getTarget()))return;
        setTarget(level().getEntitiesOfClass(LivingEntity.class,getBoundingBox().inflate(12),
            this::automaticEnemy).stream().min(Comparator.comparingDouble(this::distanceToSqr)).orElse(null));
    }
    public void updatePatrol(LivingEntity owner) { patrol.update(owner); }
    @Override public void tick() {
        super.tick();if(level().isClientSide || !isAlive())return;
        if(--ticksLeft<=0) { discard();return; }
        if(tickCount%10==0) {
            var owner=getOwner();if(owner!=null)patrol.tryReturnToOwner(owner);
        }
        if(tickCount%10==0 || getTarget()!=null && !validEnemy(getTarget()))updateCombatTarget();
    }
    /** Same damage classification and accounting as vanilla witches, with 50% reduction. */
    @Override protected float getDamageAfterMagicAbsorb(DamageSource source,float amount) {
        amount=super.getDamageAfterMagicAbsorb(source,amount);
        if(source.is(net.minecraft.tags.DamageTypeTags.WITCH_RESISTANT_TO)) {
            this.damageContainers.peek().setReduction(net.neoforged.neoforge.common.damagesource.DamageContainer.Reduction.INNATE_RESISTANCE,amount*0.5f);
            amount*=0.5f;
        }
        return amount;
    }
    @Override public boolean hurt(DamageSource source,float amount) {
        boolean accepted=super.hurt(source,amount);
        if(accepted && !level().isClientSide && isAlive()) {
            if((retaliationTarget==null || !validEnemy(retaliationTarget))
                    && source.getEntity() instanceof LivingEntity attacker && validEnemy(attacker))retaliationTarget=attacker;
            updateCombatTarget();
        }
        return accepted;
    }
    @Override public void die(DamageSource source) {
        super.die(source);
        if(!level().isClientSide && dead && !deathEventSent) { deathEventSent=true;onSummonDeath(level(),source,false); }
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);if(ownerId!=null)tag.putUUID("WarriorOwner",ownerId);
        tag.putInt("WarriorLifetime",ticksLeft);tag.putBoolean("WarriorDeathEventSent",deathEventSent);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);ownerId=tag.hasUUID("WarriorOwner")?tag.getUUID("WarriorOwner"):null;
        ticksLeft=tag.contains("WarriorLifetime")?tag.getInt("WarriorLifetime"):1200;deathEventSent=tag.getBoolean("WarriorDeathEventSent");
    }
}

