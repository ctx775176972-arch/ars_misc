package dev.arsmisc.entity;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import java.util.Comparator;

/** Keeps native melee timing while defending against enemies blocking the preferred target. */
public final class WarriorMeleeGoal extends MeleeAttackGoal {
    private final SummonedWarrior warrior;
    private LivingEntity pathedTarget;
    private long nextRepath;
    public WarriorMeleeGoal(SummonedWarrior warrior) { super(warrior,1.0,true);this.warrior=warrior; }
    private LivingEntity closeEnemy() {
        return warrior.level().getEntitiesOfClass(LivingEntity.class,warrior.getBoundingBox().inflate(3),
            e->warrior.automaticEnemy(e) && warrior.isWithinMeleeAttackRange(e)
                && warrior.getSensing().hasLineOfSight(e)).stream()
            .min(Comparator.comparingDouble(warrior::distanceToSqr)).orElse(null);
    }
    @Override public boolean canUse() { return warrior.getTarget()!=null && warrior.validEnemy(warrior.getTarget()); }
    @Override public boolean canContinueToUse() { return canUse(); }
    @Override public void start() { super.start();pathedTarget=null;nextRepath=0; }
    @Override public void stop() { super.stop();pathedTarget=null;nextRepath=0; }
    @Override public void tick() {
        super.tick();var target=warrior.getTarget();if(target==null)return;
        long now=warrior.level().getGameTime();
        if(!warrior.isWithinMeleeAttackRange(target) && (target!=pathedTarget || now>=nextRepath)) {
            warrior.getNavigation().moveTo(target,1.0);pathedTarget=target;nextRepath=now+10;
        }
    }
    @Override protected void checkAndPerformAttack(LivingEntity preferred) {
        if(canPerformAttack(preferred)) { super.checkAndPerformAttack(preferred);return; }
        if(!isTimeToAttack())return;
        var nearby=closeEnemy();
        if(nearby!=null)super.checkAndPerformAttack(nearby);
    }
}
