package dev.arsmisc.entity;

import dev.arsmisc.ArsMiscMod;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.effect.MobEffectCategory;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.living.MobEffectEvent;

/** Restricts only the guardian's synchronous enemy dispel to beneficial effects. */
@EventBusSubscriber(modid=ArsMiscMod.MOD_ID)
public final class GuardianDispelProtection {
    private static final ThreadLocal<LivingEntity> TARGET=new ThreadLocal<>();
    private GuardianDispelProtection() { }
    public static void cast(LivingEntity target,Runnable action) {
        var previous=TARGET.get();TARGET.set(target);
        try { action.run(); }finally { if(previous==null)TARGET.remove();else TARGET.set(previous); }
    }
    @SubscribeEvent public static void removeEffect(MobEffectEvent.Remove event) {
        if(event.getEntity()==TARGET.get() && event.getEffect().value().getCategory()!=MobEffectCategory.BENEFICIAL)event.setCanceled(true);
    }
}
