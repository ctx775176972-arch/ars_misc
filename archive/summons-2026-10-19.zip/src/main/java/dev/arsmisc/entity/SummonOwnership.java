package dev.arsmisc.entity;

import com.hollingsworth.arsnouveau.api.entity.ISummon;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.*;
import java.lang.reflect.Method;
import java.util.Optional;
import java.util.UUID;

/** Optional Iron's integration uses its public summon interface without a required dependency. */
public final class SummonOwnership {
    private SummonOwnership() { }
    private static Method ironOwnerMethod(Class<?> type) {
        if(type==null)return null;
        if(type.getName().equals("io.redspace.ironsspellbooks.entity.mobs.IMagicSummon")) {
            try { return type.getMethod("getSummoner"); }catch(NoSuchMethodException ignored) { return null; }
        }
        for(var face:type.getInterfaces()) { var method=ironOwnerMethod(face);if(method!=null)return method; }
        return ironOwnerMethod(type.getSuperclass());
    }
    private static final ClassValue<Optional<Method>> IRON_OWNER=new ClassValue<>() {
        @Override protected Optional<Method> computeValue(Class<?> type) { return Optional.ofNullable(ironOwnerMethod(type)); }
    };
    public static boolean isIronSummon(Entity entity) { return IRON_OWNER.get(entity.getClass()).isPresent(); }
    public static boolean isSummon(Entity entity) { return entity instanceof ISummon || IRON_OWNER.get(entity.getClass()).isPresent(); }
    public static Entity summoner(Entity entity) {
        if(entity instanceof OwnableEntity own) {
            UUID id=own.getOwnerUUID();
            if(id!=null && entity.level() instanceof ServerLevel server) { var owner=server.getEntity(id);if(owner!=null)return owner; }
            return own.getOwner();
        }
        var method=IRON_OWNER.get(entity.getClass());
        if(method.isPresent()) {
            try { var owner=method.get().invoke(entity);return owner instanceof Entity found?found:null; }
            catch(ReflectiveOperationException ignored) { return null; }
        }
        return null;
    }
    public static UUID ownerId(Entity entity) {
        if(entity instanceof OwnableEntity own)return own.getOwnerUUID();
        var owner=summoner(entity);return owner==null?null:owner.getUUID();
    }
    public static boolean isOwnedBy(Entity entity,LivingEntity owner) {
        return owner.getUUID().equals(ownerId(entity));
    }
    public static boolean attacksOwner(Entity entity,LivingEntity owner) {
        if(!isSummon(entity))return false;
        var id=ownerId(entity);if(id==null || id.equals(owner.getUUID()))return false;
        return entity instanceof Mob mob && mob.getTarget()!=null && mob.getTarget().getUUID().equals(owner.getUUID())
            || owner.getLastHurtByMob()==entity;
    }
}
