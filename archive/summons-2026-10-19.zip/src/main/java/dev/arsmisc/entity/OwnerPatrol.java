package dev.arsmisc.entity;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.PathfinderMob;

/** Shared four-block idle patrol for owned summons. */
public final class OwnerPatrol {
    private final PathfinderMob mob;
    private double patrolAngle;
    private net.minecraft.world.phys.Vec3 patrolCenter;
    private net.minecraft.world.phys.Vec3 patrolPoint;
    private long nextPatrol;
    private long nextReturnAttempt;
    public OwnerPatrol(PathfinderMob mob) { this.mob=mob; }
    public void reset() { patrolCenter=null;patrolPoint=null;nextPatrol=0; }
    /** Independent of combat goals, like vanilla pets returning to their owner. */
    public boolean tryReturnToOwner(LivingEntity owner) {
        if(mob.level().isClientSide || owner.level()!=mob.level() || mob.distanceToSqr(owner)<144
                || mob.isPassenger() || mob.isLeashed() || owner.isSpectator())return false;
        long now=mob.level().getGameTime();if(now<nextReturnAttempt)return false;nextReturnAttempt=now+20;
        double start=Math.atan2(mob.getZ()-owner.getZ(),mob.getX()-owner.getX());
        for(int radius:new int[]{4,3,2})for(int candidate=0;candidate<8;candidate++) {
            double angle=start+candidate*Math.PI/4;
            for(int dy:new int[]{0,1,-1,2}) {
                var feet=net.minecraft.core.BlockPos.containing(owner.getX()+radius*Math.cos(angle),owner.getY()+dy,owner.getZ()+radius*Math.sin(angle));
                if(!mob.level().hasChunkAt(feet)
                        || net.minecraft.world.level.pathfinder.WalkNodeEvaluator.getPathTypeStatic(mob,feet)!=net.minecraft.world.level.pathfinder.PathType.WALKABLE)continue;
                var point=new net.minecraft.world.phys.Vec3(feet.getX()+0.5,feet.getY(),feet.getZ()+0.5);
                var bounds=mob.getBoundingBox().move(point.subtract(mob.position()));
                if(!mob.level().getWorldBorder().isWithinBounds(bounds) || !mob.level().noCollision(mob,bounds))continue;
                mob.teleportTo(point.x,point.y,point.z);mob.setDeltaMovement(net.minecraft.world.phys.Vec3.ZERO);
                mob.getNavigation().stop();reset();return true;
            }
        }
        return false;
    }
    /** Walk between reachable points about four blocks from the owner; do not navigate into them. */
    public void update(LivingEntity owner) {
        long now=mob.level().getGameTime();
        if(mob.distanceToSqr(owner)>=144) { tryReturnToOwner(owner);return; }
        boolean moved=patrolCenter==null || patrolCenter.distanceToSqr(owner.position())>1;
        if(!moved && patrolPoint!=null && now<nextPatrol)return;
        double start=patrolPoint==null?Math.atan2(mob.getZ()-owner.getZ(),mob.getX()-owner.getX()):patrolAngle+Math.PI/3;
        for(int candidate=0;candidate<8;candidate++) {
            double angle=start+candidate*Math.PI/4;
            double x=owner.getX()+4*Math.cos(angle),z=owner.getZ()+4*Math.sin(angle);
            for(int dy:new int[]{0,1,-1,2}) {
                var feet=net.minecraft.core.BlockPos.containing(x,owner.getY()+dy,z);
                if(!mob.level().getBlockState(feet.below()).isFaceSturdy(mob.level(),feet.below(),net.minecraft.core.Direction.UP)
                    || !mob.level().getFluidState(feet).isEmpty())continue;
                var point=new net.minecraft.world.phys.Vec3(x,feet.getY(),z);
                if(!mob.level().noCollision(mob,mob.getBoundingBox().move(point.subtract(mob.position()))))continue;
                var path=mob.getNavigation().createPath(feet,0);
                if(path==null || !path.canReach())continue;
                mob.getNavigation().moveTo(path,1.0);
                patrolAngle=angle;patrolCenter=owner.position();patrolPoint=point;nextPatrol=now+60;
                return;
            }
        }
        // Obstructed terrain should not push the guardian into the owner or teleport it into blocks.
        mob.getNavigation().stop();patrolPoint=null;nextPatrol=now+20;
    }
}
