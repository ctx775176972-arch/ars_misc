package dev.arsmisc.entity;

import com.hollingsworth.arsnouveau.api.entity.*;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.method.*;
import com.hollingsworth.arsnouveau.common.spell.effect.*;
import com.hollingsworth.arsnouveau.common.spell.augment.*;
import dev.arsmisc.EffectRegeneration;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.monster.Evoker;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import java.util.*;

/** Support-only evoker model entity, using native Ars summons and spell resolution. */
public final class SummonedGuardian extends Evoker implements ISummon, IDispellable {
    private UUID ownerId;
    private LivingEntity ownerCache;
    private int ticksLeft=1200;
    private long invisibleUntil;
    private long nextEscape;
    private boolean deathEventSent;
    private long castAnimationUntil;
    private LivingEntity castAnimationTarget;
    private LivingEntity ownerDamageTarget;
    private final Map<UUID,Long> nextDispel=new HashMap<>();
    private final OwnerPatrol patrol=new OwnerPatrol(this);

    public SummonedGuardian(EntityType<? extends Evoker> type,Level level) { super(type,level);setPersistenceRequired(); }
    public static AttributeSupplier.Builder guardianAttributes() {
        return Evoker.createAttributes();
    }
    @Override protected void registerGoals() {
        goalSelector.addGoal(0,new FloatGoal(this));
        goalSelector.addGoal(1,new Goal() {
            { setFlags(EnumSet.of(Goal.Flag.LOOK)); }
            @Override public boolean canUse() { return isCastingSpell() && castAnimationTarget!=null && castAnimationTarget!=SummonedGuardian.this && castAnimationTarget.isAlive(); }
            @Override public void tick() { getLookControl().setLookAt(castAnimationTarget,30,30); }
        });
        goalSelector.addGoal(2,new LookAtPlayerGoal(this,net.minecraft.world.entity.player.Player.class,8));
        goalSelector.addGoal(3,new RandomLookAroundGoal(this));
    }
    @Override public void checkDespawn() { }
    @Override protected int getBaseExperienceReward() { return 0; }
    @Override public UUID getOwnerUUID() { return ownerId; }
    @Override public LivingEntity getOwner() {
        if(ownerCache!=null && ownerCache.isAlive() && ownerCache.level()==level())return ownerCache;
        if(ownerId!=null && level() instanceof ServerLevel server && server.getEntity(ownerId) instanceof LivingEntity living) { ownerCache=living;return living; }
        return null;
    }
    public void bindOwner(LivingEntity owner) { ownerCache=owner;ownerId=owner.getUUID(); }
    @Override public void setOwnerID(UUID id) { ownerId=id;if(ownerCache!=null && !id.equals(ownerCache.getUUID()))ownerCache=null; }
    @Override public int getTicksLeft() { return ticksLeft; }
    @Override public void setTicksLeft(int ticks) { ticksLeft=Math.max(0,ticks); }
    @Override public boolean onDispel(LivingEntity caster) { discard();return true; }
    @Override public void tick() {
        super.tick();
        if(level().isClientSide || !isAlive())return;
        if(--ticksLeft<=0) { discard();return; }
        spellCastingTickCount=(int)Math.clamp(castAnimationUntil-level().getGameTime(),0,20);
        if(spellCastingTickCount==0) { setIsCastingSpell(IllagerSpell.NONE);castAnimationTarget=null; }
        if(invisibleUntil>0 && level().getGameTime()>=invisibleUntil) {
            // Vanilla milk clearing does not invoke Ars dispelling or remove the summoned entity.
            Items.MILK_BUCKET.finishUsingItem(new ItemStack(Items.MILK_BUCKET),level(),this);
            invisibleUntil=0;
        }
        var owner=getOwner();if(owner==null)return;
        if(tickCount%10==0)updatePatrol(owner);
        if(tickCount%40==0)assistOnce();
    }
    public void updatePatrol(LivingEntity owner) { patrol.update(owner); }
    public boolean isBeneficiary(LivingEntity entity) {
        if(entity==this || !entity.isAlive())return false;
        var owner=getOwner();if(owner==null)return false;
        if(entity==owner)return true;
        if(SummonOwnership.isOwnedBy(entity,owner))return true;
        // Touhou Little Maid exposes an owner UUID; no optional mod classes are linked here.
        if(entity.getClass().getName().startsWith("com.github.tartaricacid.touhoulittlemaid.")) {
            try { return ownerId.equals(entity.getClass().getMethod("getOwnerUUID").invoke(entity)); }
            catch(ReflectiveOperationException ignored) { return false; }
        }
        return false;
    }
    public List<LivingEntity> beneficiaries() {
        var list=new ArrayList<>(level().getEntitiesOfClass(LivingEntity.class,getBoundingBox().inflate(8),
            e->isBeneficiary(e) && distanceToSqr(e)<=64));
        var owner=getOwner();if(owner!=null && owner.isAlive() && distanceToSqr(owner)<=64 && !list.contains(owner))list.add(owner);
        return list;
    }
    public static int supportPriority(LivingEntity target) {
        if(target.getHealth()<target.getMaxHealth()*0.5f)return 0;
        if(target.isOnFire())return 1;
        var regen=target.getEffect(MobEffects.REGENERATION);
        return regen==null || regen.getDuration()<100?2:3;
    }
    public void recordOwnerDamage(LivingEntity target) { ownerDamageTarget=target; }
    public boolean hostileTarget(LivingEntity target) {
        var owner=getOwner();
        if(owner==null || target==this || !target.isAlive() || target.isSpectator()
                || target instanceof net.minecraft.world.entity.player.Player || isBeneficiary(target) || owner.isAlliedTo(target))return false;
        if(owner.getLastHurtByMob()==target || owner.getLastHurtMob()==target || ownerDamageTarget==target)return true;
        if(target instanceof Mob mob && mob.getTarget()!=null && isBeneficiary(mob.getTarget()))return true;
        return !SummonOwnership.isSummon(target) && target instanceof net.minecraft.world.entity.monster.Enemy;
    }
    public boolean canDispelEnemy(LivingEntity target) {
        if(!hostileTarget(target))return false;
        if(target instanceof ISummon && target instanceof IDispellable)return true;
        return target.getActiveEffects().stream().anyMatch(effect->effect.getEffect().value().getCategory()==MobEffectCategory.BENEFICIAL
            && (effect.getCures().contains(net.neoforged.neoforge.common.EffectCures.MILK)
                ?!effect.getEffect().is(com.hollingsworth.arsnouveau.common.lib.PotionEffectTags.DISPEL_DENY)
                :effect.getEffect().is(com.hollingsworth.arsnouveau.common.lib.PotionEffectTags.DISPEL_ALLOW)));
    }
    private LivingEntity dispelTarget() {
        long now=level().getGameTime();
        if(nextDispel.size()>128)nextDispel.entrySet().removeIf(e->e.getValue()<=now);
        return level().getEntitiesOfClass(LivingEntity.class,getBoundingBox().inflate(8),
            e->distanceToSqr(e)<=64 && nextDispel.getOrDefault(e.getUUID(),0L)<=now && canDispelEnemy(e)).stream()
            .min(Comparator.<LivingEntity>comparingInt(e->e instanceof ISummon && e instanceof IDispellable?0:1)
                .thenComparingDouble(this::distanceToSqr)).orElse(null);
    }
    public void assistOnce() {
        var target=beneficiaries().stream().filter(e->supportPriority(e)<3)
            .min(Comparator.<LivingEntity>comparingInt(SummonedGuardian::supportPriority)
                .thenComparingDouble(e->e.getHealth()/e.getMaxHealth()).thenComparingInt(Entity::getId)).orElse(null);
        if(target!=null && supportPriority(target)<=1) {
            Spell spell=supportPriority(target)==0
                ?new Spell(MethodTouch.INSTANCE,EffectHeal.INSTANCE,AugmentAmplify.INSTANCE)
                :new Spell(MethodTouch.INSTANCE,EffectConjureWater.INSTANCE);
            castSupport(spell,target);return;
        }
        var enemy=dispelTarget();
        if(enemy!=null) {
            nextDispel.put(enemy.getUUID(),level().getGameTime()+100);
            GuardianDispelProtection.cast(enemy,()->castSupport(new Spell(MethodTouch.INSTANCE,EffectDispel.INSTANCE),enemy));return;
        }
        if(target!=null)castSupport(new Spell(MethodTouch.INSTANCE,EffectRegeneration.INSTANCE,AugmentExtendTime.INSTANCE),target);
    }
    private void castSupport(Spell spell,LivingEntity target) {
        var context=SpellContext.fromEntity(spell,this,ItemStack.EMPTY);
        var resolver=new SpellResolver(context) {
            @Override protected boolean enoughMana(LivingEntity caster) { return true; }
            @Override public void expendMana() { }
        };
        resolver.withSilent(true);
        boolean cast=spell.getCastMethod()==MethodSelf.INSTANCE
            ?resolver.onCast(ItemStack.EMPTY,level())
            :resolver.onCastOnEntity(ItemStack.EMPTY,target,InteractionHand.MAIN_HAND);
        if(cast) {
            castAnimationTarget=target;castAnimationUntil=level().getGameTime()+20;spellCastingTickCount=20;
            setIsCastingSpell(spell.getCastMethod()==MethodSelf.INSTANCE?IllagerSpell.DISAPPEAR:IllagerSpell.SUMMON_VEX);
        }
    }
    @Override public void die(DamageSource source) {
        super.die(source);
        // The native dead flag is set only after an accepted death, including death-event cancellation.
        if(!level().isClientSide && dead && !deathEventSent) {
            deathEventSent=true;
            onSummonDeath(level(),source,false);
        }
    }
    @Override public boolean hurt(DamageSource source,float amount) {
        boolean hit=super.hurt(source,amount);
        if(hit && isAlive() && !level().isClientSide && level().getGameTime()>=nextEscape) {
            castSupport(new Spell(MethodSelf.INSTANCE,EffectInvisibility.INSTANCE),this);
            if(hasEffect(MobEffects.INVISIBILITY)) {
                invisibleUntil=level().getGameTime()+60;nextEscape=level().getGameTime()+200;
            }
        }
        return hit;
    }
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);if(ownerId!=null)tag.putUUID("GuardianOwner",ownerId);
        tag.putInt("GuardianLifetime",ticksLeft);tag.putLong("GuardianInvisibleUntil",invisibleUntil);tag.putLong("GuardianNextEscape",nextEscape);
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);ownerId=tag.hasUUID("GuardianOwner")?tag.getUUID("GuardianOwner"):null;
        ticksLeft=tag.contains("GuardianLifetime")?tag.getInt("GuardianLifetime"):1200;
        invisibleUntil=tag.getLong("GuardianInvisibleUntil");nextEscape=tag.getLong("GuardianNextEscape");
    }
}

