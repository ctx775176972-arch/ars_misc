package dev.arsmisc.registry;

import dev.arsmisc.ArsMiscMod;
import dev.arsmisc.entity.SummonedGuardian;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.*;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.*;

public final class ModEntities {
    private static final DeferredRegister<EntityType<?>> ENTITIES=DeferredRegister.create(Registries.ENTITY_TYPE,ArsMiscMod.MOD_ID);
    public static final DeferredHolder<EntityType<?>,EntityType<SummonedGuardian>> SUMMONED_GUARDIAN=ENTITIES.register("summoned_guardian",
        ()->EntityType.Builder.<SummonedGuardian>of(SummonedGuardian::new,MobCategory.CREATURE).sized(0.6f,1.95f).clientTrackingRange(8).build("ars_misc:summoned_guardian"));
    public static final DeferredHolder<EntityType<?>,EntityType<dev.arsmisc.entity.SummonedWarrior>> SUMMONED_WARRIOR=ENTITIES.register("summoned_warrior",
        ()->EntityType.Builder.<dev.arsmisc.entity.SummonedWarrior>of(dev.arsmisc.entity.SummonedWarrior::new,MobCategory.CREATURE).sized(0.6f,1.95f).clientTrackingRange(8).build("ars_misc:summoned_warrior"));
    public static void register(IEventBus bus) {
        ENTITIES.register(bus);
        bus.addListener((net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent event)->{ event.put(SUMMONED_GUARDIAN.get(),SummonedGuardian.guardianAttributes().build()); event.put(SUMMONED_WARRIOR.get(),dev.arsmisc.entity.SummonedWarrior.warriorAttributes().build()); });
    }
}
