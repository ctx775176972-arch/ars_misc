package dev.arsmisc;

import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.augment.*;
import dev.arsmisc.registry.ModEntities;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.HitResult;
import net.neoforged.neoforge.common.ModConfigSpec;
import java.util.Set;

public final class EffectSummonGuardian extends AbstractEffect {
    @Override public boolean shouldShowInSpellBook() { return false; }
    @Override public boolean shouldShowInUnlock() { return false; }
    public static final EffectSummonGuardian INSTANCE=new EffectSummonGuardian();
    private EffectSummonGuardian() { super(ResourceLocation.fromNamespaceAndPath(ArsMiscMod.MOD_ID,"glyph_summon_guardian"),"Summon Guardian"); }
    @Override public void onResolve(HitResult hit,Level level,LivingEntity caster,SpellStats stats,SpellContext context,SpellResolver resolver) {
        if(level.isClientSide || !canSummon(caster))return;
        int duration=Math.max(1,getBaseDuration()*20+getExtendTimeDuration()*stats.getDurationInTicks());
        var guardian=ModEntities.SUMMONED_GUARDIAN.get().create(level);if(guardian==null)return;
        var pos=safelyGetHitPos(hit);guardian.moveTo(pos.x,pos.y+0.1,pos.z,caster.getYRot(),0);
        guardian.bindOwner(caster);guardian.setTicksLeft(duration);
        summonLivingEntity(hit,level,caster,stats,context,resolver,guardian);
        applySummoningSickness(caster,duration);
    }
    @Override public SpellTier defaultTier() { return SpellTier.TWO; }
    @Override public int getDefaultManaCost() { return 300; }
    @Override public Set<AbstractAugment> getCompatibleAugments() { return setOf(AugmentExtendTime.INSTANCE,AugmentDurationDown.INSTANCE); }
    @Override public void addAugmentDescriptions(java.util.Map<AbstractAugment,String> descriptions) {
        super.addAugmentDescriptions(descriptions);
        descriptions.put(AugmentExtendTime.INSTANCE,"Extends summon lifetime and Summoning Sickness.");
        descriptions.put(AugmentDurationDown.INSTANCE,"Shortens summon lifetime and Summoning Sickness.");
    }
    @Override public Set<SpellSchool> getSchools() { return setOf(SpellSchools.ABJURATION); }
    @Override public void buildConfig(ModConfigSpec.Builder builder) { super.buildConfig(builder);addPotionConfig(builder,60);addExtendTimeConfig(builder,15); }
    public int getBaseDuration() { return POTION_TIME==null?60:POTION_TIME.get(); }
    public int getExtendTimeDuration() { return EXTEND_TIME==null?15:EXTEND_TIME.get(); }
    @Override public String getBookDescription() { return "Summons a guardian for 60 seconds and applies native Summoning Sickness. It supports its owner and owned companions with healing, regeneration and extinguishing, automatically dispels hostile buffs and dispellable enemy summons, and briefly turns invisible after surviving a hit."; }
}

