package dev.arsmisc.client;

import dev.arsmisc.ArsMiscMod;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.VindicatorRenderer;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.monster.Vindicator;

/** Keeps native vindicator poses and held-item visibility. */
public final class WarriorRenderer extends VindicatorRenderer {
    private static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath(ArsMiscMod.MOD_ID,"textures/entity/summoned_warrior.png");
    public WarriorRenderer(EntityRendererProvider.Context context) { super(context); }
    @Override public ResourceLocation getTextureLocation(Vindicator entity) { return TEXTURE; }
}
