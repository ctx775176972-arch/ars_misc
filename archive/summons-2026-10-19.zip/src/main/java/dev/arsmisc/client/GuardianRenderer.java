package dev.arsmisc.client;

import dev.arsmisc.ArsMiscMod;
import dev.arsmisc.entity.SummonedGuardian;
import net.minecraft.client.model.IllagerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.resources.ResourceLocation;

public final class GuardianRenderer extends MobRenderer<SummonedGuardian,IllagerModel<SummonedGuardian>> {
    private static final ResourceLocation TEXTURE=ResourceLocation.fromNamespaceAndPath(ArsMiscMod.MOD_ID,"textures/entity/summoned_guardian.png");
    public GuardianRenderer(EntityRendererProvider.Context context) { super(context,new IllagerModel<>(context.bakeLayer(ModelLayers.EVOKER)),0.5f); }
    @Override public ResourceLocation getTextureLocation(SummonedGuardian entity) { return TEXTURE; }
}
