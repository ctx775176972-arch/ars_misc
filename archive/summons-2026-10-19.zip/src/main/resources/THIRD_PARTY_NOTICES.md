Ars Misc's original source is MIT licensed.
Bundled, unmodified Sauce Library 0.0.62 by Alexthw retains LGPL-3.0 licensing.
Source: https://github.com/Alexthw46/SauceLib
Most Ars Nouveau textures are referenced from the installed Ars Nouveau mod.
assets/ars_misc/textures/item/glyph_regeneration.png is derived from Ars Nouveau
5.13.3's assets/ars_nouveau/textures/item/charm.png. Only the black heart was
recolored red. The original frame, background, transparency and pixel layout
remain unchanged. This asset retains its upstream rights and is not covered
by Ars Misc's MIT license. Ars Nouveau's README encourages asset reuse by addons.
assets/ars_misc/textures/item/glyph_sacrificial_shield.png uses the Ars Nouveau
glyph frame from a user-provided shield reference. The shield was filled black
and given a red cross with two-pixel-wide strokes on the original glyph grid.
The reference frame, background and transparency were preserved. This asset
retains its upstream rights and is not covered by Ars Misc's MIT license.
assets/ars_misc/textures/item/critical_necklace.png and critical_belt.png are
recolored directly from Ars Nouveau's amulet_of_mana_regen.png and
mundane_belt.png, preserving their pixel layouts and alpha masks.
Their upstream asset rights are not covered by the
project's MIT source-code license.
assets/ars_misc/textures/item/enchanters_field.png extracts and recolors the
central concentric-circle pixels of Ars Nouveau's textures/item/aoe.png.
Its upstream asset rights are not covered by the project's MIT source license.
assets/ars_misc/textures/item/glyph_flight.png uses the effect glyph template
from baileyholl/Ars-Nouveau-Example-Addon (1.21.1, Unlicense):
https://github.com/baileyholl/Ars-Nouveau-Example-Addon
The figure is extracted from Ars Nouveau's ritual_flight.png and recolored
dark for the glyph and white over blank_thread.png for thread_creative_flight.png.
These Ars Nouveau-derived pixels retain their upstream asset rights.
The defense thread textures also use Ars Nouveau's blank_thread.png.
thread_resilient.png overlays a white recolor of the shield from glyph_crystal_shield.png;
thread_sturdy.png overlays a white recolor of Minecraft's HUD armor_full.png.
These source assets retain their respective upstream rights.
assets/ars_misc/textures/mob_effect/decay.png derives from Ars Elemental
0.7.10.4's textures/mob_effect/hymn_of_order.png. The original head pixels and
transparency are preserved except for red recolors of the eyes and a black surrounding
symbol. This asset retains its upstream rights outside the MIT source license.
assets/ars_misc/textures/item/glyph_life_sense.png uses the same example addon's
blank effect glyph template with a resized, black silhouette extracted from the
user-provided goggles reference. The underlying template pixels are preserved.
Ars Nouveau: https://github.com/baileyholl/Ars-Nouveau
This test build pins Sauce 0.0.62 because its critical-roll integration targets that implementation.

assets/ars_misc/textures/item/glyph_decay.png recolors only the four eye pixels
of Ars Nouveau 5.13.3's textures/item/wither.png red; all other pixels remain
unchanged. This asset retains its upstream rights outside the MIT source license.
