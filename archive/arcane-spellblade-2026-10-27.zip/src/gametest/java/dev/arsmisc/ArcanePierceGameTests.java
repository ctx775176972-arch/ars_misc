package dev.arsmisc;

import com.hollingsworth.arsnouveau.api.perk.PerkAttributes;
import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.common.spell.augment.AugmentAmplify;
import com.hollingsworth.arsnouveau.common.spell.effect.EffectHarm;
import com.hollingsworth.arsnouveau.common.spell.method.MethodTouch;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.gametest.framework.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.item.*;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.neoforge.common.Tags;
import net.neoforged.neoforge.gametest.*;

@GameTestHolder("ars_misc") @PrefixGameTestTemplate(false)
public final class ArcanePierceGameTests {
    private static ServerPlayer player(GameTestHelper h) {
        var p = ReactiveShieldGameTests.player(h);
        p.getAttribute(com.alexthw.sauce.registry.ModRegistry.SPELL_CRIT).setBaseValue(0);
        BuiltInRegistries.ATTRIBUTE.getHolder(ResourceLocation.parse("apothic_attributes:crit_chance"))
                .ifPresent(attribute -> p.getAttribute(attribute).setBaseValue(0));
        return p;
    }
    private static float hit(GameTestHelper h, ServerPlayer p, AbstractEffect effect, int amplify,
            boolean armor, boolean protection, boolean resistance) {
        var target = h.spawnWithNoFreeWill(EntityType.HUSK, 2, 2, 4);
        target.getAttribute(Attributes.MAX_HEALTH).setBaseValue(100);
        target.getAttribute(Attributes.ARMOR).setBaseValue(armor ? 30 : 0);
        target.getAttribute(Attributes.ARMOR_TOUGHNESS).setBaseValue(armor ? 20 : 0);
        target.setHealth(100);
        if (protection) {
            // A worn enchanted book supplies protection without any armor attributes.
            var piece = new ItemStack(Items.BOOK);
            piece.enchant(h.getLevel().holderOrThrow(Enchantments.PROTECTION), 10);
            target.setItemSlot(EquipmentSlot.CHEST, piece);
        }
        if (resistance) target.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 0));
        var spell = new Spell(MethodTouch.INSTANCE, effect);
        var context = SpellContext.fromEntity(spell, p, ItemStack.EMPTY);
        var stats = new SpellStats.Builder();
        for (int i = 0; i < amplify; i++) stats.addAugment(AugmentAmplify.INSTANCE);
        var hit = new EntityHitResult(target);
        effect.onResolveEntity(hit, h.getLevel(), p, stats.build(effect, hit, h.getLevel(), p, context),
                context, new SpellResolver(context));
        h.assertTrue(target.getLastDamageSource() != null && target.getLastDamageSource().getEntity() == p,
                "Arcane Pierce lost the real caster");
        float result = 100 - target.getHealth(); target.discard(); return result;
    }

    @GameTest(template="empty", templateNamespace="ars_misc")
    public static void glyphDamageTypeRecipeAndAugmentsAreRegistered(GameTestHelper h) {
        var source = EffectArcanePierce.INSTANCE.buildDamageSource(h.getLevel(), player(h));
        h.assertTrue(source.is(DamageTypeTags.BYPASSES_ARMOR) && source.is(Tags.DamageTypes.IS_MAGIC)
                && !source.is(DamageTypeTags.BYPASSES_ENCHANTMENTS)
                && !source.is(DamageTypeTags.BYPASSES_RESISTANCE), "Arcane Pierce has incorrect damage tags");
        h.assertTrue(EffectArcanePierce.INSTANCE.getDefaultManaCost() == 60
                && EffectArcanePierce.INSTANCE.defaultTier() == SpellTier.TWO
                && EffectArcanePierce.INSTANCE.getCompatibleAugments().contains(AugmentAmplify.INSTANCE)
                && EffectArcanePierce.INSTANCE.getAugmentLimit(AugmentAmplify.INSTANCE.getRegistryName()) == 1,
                "Unexpected Arcane Pierce defaults");
        h.assertTrue(BuiltInRegistries.ITEM.containsKey(ResourceLocation.parse("ars_misc:glyph_arcane_pierce"))
                && h.getLevel().getRecipeManager().byKey(ResourceLocation.parse("ars_misc:glyph_arcane_pierce")).isPresent(),
                "Arcane Pierce glyph or learning recipe is missing");
        h.succeed();
    }

    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void armorIsBypassedButProtectionAndResistanceStillReduceDamage(GameTestHelper h) {
        var p = player(h);
        float raw = hit(h, p, EffectArcanePierce.INSTANCE, 0, false, false, false);
        float armored = hit(h, p, EffectArcanePierce.INSTANCE, 0, true, false, false);
        float harm = hit(h, p, EffectHarm.INSTANCE, 0, true, false, false);
        float protection = hit(h, p, EffectArcanePierce.INSTANCE, 0, true, true, false);
        float resistance = hit(h, p, EffectArcanePierce.INSTANCE, 0, true, false, true);
        h.assertTrue(Math.abs(raw - 5) < 0.001 && Math.abs(armored - raw) < 0.001 && harm < raw
                && protection > 0 && protection < raw && Math.abs(resistance - 4) < 0.001,
                "Incorrect reductions: raw=" + raw + " armored=" + armored + " harm=" + harm
                        + " protection=" + protection + " resistance=" + resistance);
        h.succeed();
    }

    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void amplifySpellPowerDamageMultiplierAndCriticalDamageRemainNative(GameTestHelper h) {
        var p = player(h);
        p.getAttribute(Attributes.ATTACK_DAMAGE).setBaseValue(10);
        h.assertTrue(Math.abs(hit(h, p, EffectArcanePierce.INSTANCE, 1, true, false, false) - 17) < 0.001,
                "Amplify did not add two damage and inherit Attack Damage");
        p.getAttribute(PerkAttributes.SPELL_DAMAGE_BONUS).setBaseValue(4);
        p.getAttribute(com.alexthw.sauce.registry.ModRegistry.SPELL_DAMAGE_MULTIPLIER).setBaseValue(1.15);
        p.getAttribute(com.alexthw.sauce.registry.ModRegistry.SPELL_CRIT).setBaseValue(1);
        p.getAttribute(com.alexthw.sauce.registry.ModRegistry.SPELL_CRIT_DAMAGE).setBaseValue(1);
        float damage = hit(h, p, EffectArcanePierce.INSTANCE, 0, true, false, false);
        h.assertTrue(Math.abs(damage - 20.7) < 0.001, "Native spell power, multiplier or critical calculation changed: " + damage);
        float amplified = hit(h, p, EffectArcanePierce.INSTANCE, 1, true, false, false);
        h.assertTrue(Math.abs(amplified - 48.3) < 0.001,
                "Inherited attack damage did not enter native spell multipliers: " + amplified);
        h.succeed();
    }

    @GameTest(template="combat_arena", templateNamespace="ars_misc")
    public static void heldWeaponModifiersAndStrengthAreInheritedButSharpnessIsNot(GameTestHelper h) {
        var p = player(h);
        var weapon = new ItemStack(Items.DIAMOND_SWORD);
        weapon.enchant(h.getLevel().holderOrThrow(Enchantments.SHARPNESS), 5);
        weapon.set(net.minecraft.core.component.DataComponents.ATTRIBUTE_MODIFIERS,
                net.minecraft.world.item.component.ItemAttributeModifiers.builder()
                        .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(ResourceLocation.parse("ars_misc:test_weapon"),
                                9, AttributeModifier.Operation.ADD_VALUE), EquipmentSlotGroup.MAINHAND)
                        .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(ResourceLocation.parse("ars_misc:test_weapon_multiplier"),
                                0.5, AttributeModifier.Operation.ADD_MULTIPLIED_TOTAL), EquipmentSlotGroup.MAINHAND).build());
        p.setItemSlot(EquipmentSlot.MAINHAND, weapon);
        p.doTick();
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 1));
        double attack = p.getAttributeValue(Attributes.ATTACK_DAMAGE);
        h.assertTrue(Math.abs(attack - 24) < 0.001, "Weapon or Strength attributes were not applied: " + attack);
        h.assertTrue(Math.abs(hit(h, p, EffectArcanePierce.INSTANCE, 0, true, false, false) - 5) < 0.001,
                "Unamplified spell inherited weapon damage");
        h.assertTrue(Math.abs(hit(h, p, EffectArcanePierce.INSTANCE, 1, true, false, false) - 31) < 0.001,
                "Amplified spell did not inherit exactly the current attack attribute");
        p.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        p.removeEffect(MobEffects.DAMAGE_BOOST);
        p.doTick();
        h.assertTrue(Math.abs(hit(h, p, EffectArcanePierce.INSTANCE, 1, true, false, false) - 8) < 0.001,
                "Spell retained stale weapon or Strength attributes");
        h.succeed();
    }
}
