package dev.arsmisc;

import com.hollingsworth.arsnouveau.api.spell.*;
import com.hollingsworth.arsnouveau.api.util.DamageUtil;
import com.hollingsworth.arsnouveau.common.spell.augment.*;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.neoforged.neoforge.common.ModConfigSpec;

import java.util.Set;
import java.util.Map;

/** Direct spell damage that bypasses armor, but retains other damage reductions. */
public final class EffectArcanePierce extends AbstractEffect implements IDamageEffect {
    public static final EffectArcanePierce INSTANCE = new EffectArcanePierce();
    public static final ResourceKey<DamageType> DAMAGE_TYPE = ResourceKey.create(Registries.DAMAGE_TYPE,
            ResourceLocation.fromNamespaceAndPath(ArsMiscMod.MOD_ID, "arcane_pierce"));

    private EffectArcanePierce() {
        super(ResourceLocation.fromNamespaceAndPath(ArsMiscMod.MOD_ID, "glyph_arcane_pierce"), "Arcane Spellblade");
    }

    @Override public void onResolveEntity(EntityHitResult hit, Level level, LivingEntity caster,
            SpellStats stats, SpellContext context, SpellResolver resolver) {
        if (level.isClientSide) return;
        float damage = (float)(DAMAGE.get() + AMP_VALUE.get() * stats.getAmpMultiplier());
        if (stats.getBuffCount(AugmentAmplify.INSTANCE) > 0 && caster != null
                && caster.getAttribute(Attributes.ATTACK_DAMAGE) != null) {
            damage += (float) caster.getAttributeValue(Attributes.ATTACK_DAMAGE);
        }
        attemptDamage(level, caster, stats, context, resolver, hit.getEntity(),
                buildDamageSource(level, caster), damage);
    }

    @Override public DamageSource buildDamageSource(Level level, LivingEntity caster) {
        return DamageUtil.source(level, DAMAGE_TYPE, caster);
    }

    @Override public SpellTier defaultTier() { return SpellTier.TWO; }
    @Override public int getDefaultManaCost() { return 60; }
    @Override public Set<SpellSchool> getSchools() { return setOf(SpellSchools.CONJURATION); }
    @Override public Set<AbstractAugment> getCompatibleAugments() {
        return augmentSetOf(AugmentAmplify.INSTANCE, AugmentDampen.INSTANCE,
                AugmentFortune.INSTANCE, AugmentRandomize.INSTANCE);
    }
    @Override public int getAugmentLimit(ResourceLocation augment) {
        int configured = super.getAugmentLimit(augment);
        return augment.equals(AugmentAmplify.INSTANCE.getRegistryName()) ? Math.min(1, configured) : configured;
    }
    @Override protected void addDefaultAugmentLimits(Map<ResourceLocation, Integer> limits) {
        limits.put(AugmentAmplify.INSTANCE.getRegistryName(), 1);
    }
    @Override public void addAugmentDescriptions(Map<AbstractAugment, String> descriptions) {
        super.addAugmentDescriptions(descriptions);
        descriptions.put(AugmentAmplify.INSTANCE,
                "Increases damage and adds the caster's Attack Damage attribute.");
    }
    @Override public void buildConfig(ModConfigSpec.Builder builder) {
        super.buildConfig(builder);
        addDamageConfig(builder, 5);
        addAmpConfig(builder, 2);
    }
    @Override public String getBookDescription() {
        return "Deals armor-piercing spell damage to the target. Amplify increases damage and adds the caster's Attack Damage attribute.";
    }
}
